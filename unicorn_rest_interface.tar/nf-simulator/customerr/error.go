package customerror

import "errors"

//ErrInvalidJSONString is error which represents Invalid JSON string
var ErrInvalidJSONString = errors.New("Invalid JSON string")

//ErrInvalidJSONPath is error which represents JSON Path doesn't exists
var ErrInvalidJSONPath = errors.New("JSON path doesn't exist")

//ErrInvalidJSONFile is error which represents Invalid JSON File
var ErrInvalidJSONFile = errors.New("Invalid JSON File")

//ErrInvalidArgs is error which represents Invalid JSON File
var ErrInvalidArgs = errors.New("Unexpected number of arguments")

//ErrHeaderNotMatching is error which represents mismatch in expected and received header
var ErrHeaderNotMatching = errors.New("The received header is not matching the expected header")

//ErrBodyFieldNotMatching is error which represents mismatch in expected and received header
var ErrBodyFieldNotMatching = errors.New("The received request or response body field is not matching the expected body field")

//ErrStatusCodeNotMatching is error which represents mismatch in expected and received header
var ErrStatusCodeNotMatching = errors.New("The response status code is not matching")

//HeaderFieldNotPresent error represents the header field looking for is not present.
func HeaderFieldNotPresent(headerField string) error {
	return errors.New("Header field -" + headerField + "not present")
}

//BodyFieldNotPresent error represents the  JSON body field looking for is not present
func BodyFieldNotPresent(bodyField string) error {
	return errors.New("Body field -" + bodyField + "not present")
}

//KeyNotPresent returns key not present error.
func KeyNotPresent(key string) error {
	return errors.New("Key -" + key + "not present")
}

//RaisePanic raises the panuc in case of error
func RaisePanic(err error) {
	if err != nil {
		panic(err)
	}
}
