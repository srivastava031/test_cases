package call

import (
	"fmt"
	"net/http"
	"net/textproto"
	"nf-simulator/config"
	"nf-simulator/counters"
	customerror "nf-simulator/customerr"
	"nf-simulator/helper"
	"nf-simulator/http02"
	"nf-simulator/nflogger"
	"nf-simulator/test"
	"nf-simulator/testconfig"
	"os"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"golang.org/x/text/language"
	"golang.org/x/text/message"
)

var (
	messageCount         uint64
	periodicMessageCount uint64
	latencyStatsMutex    = sync.Mutex{}
	//requestBodies Will have all the request bodies, can be accessed using
	//Message ID
	requestBodies  = make(map[string]string)
	latencyStats   = make(map[string]map[int]map[string][]int64)
	statsFileMutex = sync.Mutex{}
	//isClientFailed is set to true when there is any test failure from client.
	//This is used while printing the test results.
	isClientFailed bool
	testStartTime  time.Time
)

type periodicLatencyChannels struct {
	minLatencyChannel, maxLatencyChannel, averageLatencyChannel chan int64
	completedThreadCount                                        uint64
}

func resetVariables() {
	messageCount = 0
	periodicMessageCount = 0
	requestBodies = make(map[string]string)
	latencyStats = make(map[string]map[int]map[string][]int64)
	isClientFailed = false
	testStartTime = time.Now()
}

//StoreAllRequestBodies to read and store all the request bodies
func StoreAllRequestBodies() error {
	nflogger.LogEntry()
	for _, call := range testconfig.TestConf.Client.CallFlow {
		if call.Send.HTTPBodyTemplate != "" {
			nflogger.LogInfo("Storing request body from file -", call.Send.HTTPBodyTemplate,
				call.Send.MessageID)
			reqBody, err := helper.ReadFile(call.Send.HTTPBodyTemplate)
			if err != nil {
				nflogger.LogError(err.Error())
				nflogger.LogExit()
				return err
			}
			requestBodies[call.Send.MessageID] = string(reqBody)
		}
	}
	nflogger.LogExit()
	return nil
}

func getNumberOfCallsInCallfow() int {
	var numOfCallsInCallFlow int
	for _, call := range testconfig.TestConf.Client.CallFlow {
		numOfCallsInCallFlow += call.Count
	}
	return numOfCallsInCallFlow
}

func executeCallFlow(connectionInstance test.Connection, headerStore, bodyStore map[string]string) ([]int64, error) {
	nflogger.LogEntry()
	//TODO Have to take care of ID field
	var latencies []int64
	for index, call := range testconfig.TestConf.Client.CallFlow {
		nflogger.LogInfo("Executing client call. Call index -", index+1)
		callLatencies, err := ExecuteClientCall(connectionInstance, call, headerStore, bodyStore)
		latencies = append(latencies, callLatencies...)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return nil, err
		}
	}
	nflogger.LogExit()
	return latencies, nil
}

func updateLatencyFields() {
	loadParams := testconfig.TestConf.Client.LoadParameters
	connectionsPerEndpoint := loadParams.NumberOfConnections / len(loadParams.Endpoints)
	for _, endpoint := range loadParams.Endpoints {
		latencyStats[endpoint] = map[int]map[string][]int64{}
		for connectionCounter := 0; connectionCounter < connectionsPerEndpoint; connectionCounter++ {
			latencyStats[endpoint][connectionCounter] = map[string][]int64{"min": nil, "max": nil, "average": nil}
		}
	}
}

func executeload(connectionID, endpointConnectionID, msgCount int, sleepTime, testDuration time.Duration,
	connLatencyChannel periodicLatencyChannels, headerStore, bodyStore map[string]string,
	testStopIndicator <-chan bool, clientErrorChannel chan<- string, waitGroup *sync.WaitGroup) {
	nflogger.LogEntry()
	defer waitGroup.Done()
	connectionInstance := test.Connections[connectionID]
	loadParams := testconfig.TestConf.Client.LoadParameters
	threadsPerConnection := loadParams.NumberOfThreads / loadParams.NumberOfConnections
	//These latencies are in Micro Seconds
	var minLatency, maxLatency, overallLatency, averageLatency int64
	startTime := time.Now()
	burstTimer := startTime
	prevCount, count := 0, 0
	latencyTimer := startTime
	numOfCallsInCallFlow := getNumberOfCallsInCallfow()
	var statsInterval time.Duration
	var stopTest bool
	if config.ProductConfig.Stats.StatsIntervalInSec != 0 {
		statsInterval = time.Duration(config.ProductConfig.Stats.StatsIntervalInSec) * time.Second
	} else {
		statsInterval = 300 * time.Second
	}
	for ; time.Since(startTime) <= testDuration && !stopTest; count++ {
		if count >= msgCount*int(testDuration/time.Second) {
			break
		}
		latencies, err := executeCallFlow(connectionInstance, headerStore, bodyStore)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			clientErrorChannel <- fmt.Sprintf("Exiting the test due to test Error, for more information see the logs. [Error Message - %s]", err)
			isClientFailed = true
			return
		}

		if count == 0 {
			for index, latency := range latencies {
				if index == 0 {
					continue
				} else if index == 1 {
					minLatency = latency
					maxLatency = latency
				} else {
					if latency < minLatency {
						minLatency = latency
					}
					if latency > maxLatency {
						maxLatency = latency
					}
				}
				overallLatency = overallLatency + latency
			}
		} else {
			for _, latency := range latencies {
				if minLatency == 0 || latency < minLatency {
					minLatency = latency
				}
				if latency > maxLatency {
					maxLatency = latency
				}
				overallLatency = overallLatency + latency
			}
		}
		if time.Since(latencyTimer) >= statsInterval {
			if count <= 1 {
				averageLatency = overallLatency / int64(numOfCallsInCallFlow)
			} else {
				averageLatency = overallLatency / int64((numOfCallsInCallFlow*count)-1)
			}
			connLatencyChannel.minLatencyChannel <- minLatency
			connLatencyChannel.maxLatencyChannel <- maxLatency
			connLatencyChannel.averageLatencyChannel <- averageLatency
			atomic.AddUint64(&periodicMessageCount, uint64((count-prevCount)*numOfCallsInCallFlow))
			prevCount = count
			latencyTimer = time.Now()
		}
		if count != 0 && count%msgCount == 0 {
			time.Sleep(sleepTime - time.Since(burstTimer))
			burstTimer = time.Now()
		}

		//When the testStopIndicator channel is closed the loop will be exited to stop the test case
		select {
		case <-testStopIndicator:
			stopTest = true
		default:
		}
	}

	if connLatencyChannel.completedThreadCount != uint64(threadsPerConnection) {
		atomic.AddUint64(&connLatencyChannel.completedThreadCount, 1)
	} else {
		close(connLatencyChannel.minLatencyChannel)
		close(connLatencyChannel.minLatencyChannel)
		close(connLatencyChannel.averageLatencyChannel)
	}
	if count <= 1 {
		averageLatency = overallLatency / int64(numOfCallsInCallFlow)
	} else {
		averageLatency = overallLatency / int64((numOfCallsInCallFlow*count)-1)
	}
	latencyStatsMutex.Lock()
	latencyStats[connectionInstance.EndPoint][endpointConnectionID]["min"] = append(latencyStats[connectionInstance.EndPoint][endpointConnectionID]["min"], minLatency)
	latencyStats[connectionInstance.EndPoint][endpointConnectionID]["max"] = append(latencyStats[connectionInstance.EndPoint][endpointConnectionID]["max"], maxLatency)
	latencyStats[connectionInstance.EndPoint][endpointConnectionID]["average"] = append(latencyStats[connectionInstance.EndPoint][endpointConnectionID]["average"], averageLatency)
	latencyStatsMutex.Unlock()
	atomic.AddUint64(&messageCount, uint64(count*numOfCallsInCallFlow))
	nflogger.LogExit()
	return
}

func createLatencyChannles() periodicLatencyChannels {
	var latencyCh periodicLatencyChannels
	loadParams := testconfig.TestConf.Client.LoadParameters
	threadsPerConnection := loadParams.NumberOfThreads / loadParams.NumberOfConnections
	minLatencyCh := make(chan int64, threadsPerConnection)
	maxLatencyCh := make(chan int64, threadsPerConnection)
	averageLatencyCh := make(chan int64, threadsPerConnection)
	latencyCh.minLatencyChannel = minLatencyCh
	latencyCh.maxLatencyChannel = maxLatencyCh
	latencyCh.averageLatencyChannel = averageLatencyCh
	return latencyCh
}

func computeLatencyStats(connLatencyChannels, endpointLatencyChannels periodicLatencyChannels) {
	var min, max, overall int64
	loadParams := testconfig.TestConf.Client.LoadParameters
	threadsPerConnection := loadParams.NumberOfThreads / loadParams.NumberOfConnections
	for i := 1; true; i++ {
		value, minOk := <-connLatencyChannels.minLatencyChannel
		if min == 0 {
			min = value
		} else if value < min {
			min = value
		}
		value, maxOk := <-connLatencyChannels.maxLatencyChannel
		if value > max {
			max = value
		}
		value, averageOk := <-connLatencyChannels.averageLatencyChannel
		overall += value
		if !minOk && !maxOk && !averageOk {
			if endpointLatencyChannels.completedThreadCount != uint64(threadsPerConnection) {
				atomic.AddUint64(&endpointLatencyChannels.completedThreadCount, 1)
			} else {
				close(endpointLatencyChannels.minLatencyChannel)
				close(endpointLatencyChannels.maxLatencyChannel)
				close(endpointLatencyChannels.averageLatencyChannel)
			}
			break
		}
		if i%threadsPerConnection == 0 {
			endpointLatencyChannels.minLatencyChannel <- min
			endpointLatencyChannels.maxLatencyChannel <- max
			endpointLatencyChannels.averageLatencyChannel <- (overall / int64(i))
		}
	}
}

func writeEndPointLatencies(endpointID, connectionID int, endpointLatencyChannels periodicLatencyChannels, statsOutFO *os.File) {
	loadParams := testconfig.TestConf.Client.LoadParameters
	connectionsPerEndpoint := loadParams.NumberOfConnections / len(loadParams.Endpoints)
	endpoint := test.Connections[connectionID].EndPoint
	var connIndex int
	statsCounter := 1
	fmtPrinter := message.NewPrinter(language.English)
	var statsInterval int
	if config.ProductConfig.Stats.StatsIntervalInSec != 0 {
		statsInterval = config.ProductConfig.Stats.StatsIntervalInSec
	} else {
		statsInterval = 300
	}
	for i := 0; true; i++ {
		minLatency, minOk := <-endpointLatencyChannels.minLatencyChannel
		maxLatency, maxOk := <-endpointLatencyChannels.maxLatencyChannel
		averageLatency, averageOk := <-endpointLatencyChannels.averageLatencyChannel
		if !minOk && !maxOk && !averageOk {
			break
		}
		if i%connectionsPerEndpoint == 0 {
			if endpointID == 1 {
				statsOutFO.Write([]byte(fmtPrinter.Sprintf("  > %s : Messages Sent : %d, TPS : %d \n", time.Now().Format("2006-01-02 15:04:05"),
					periodicMessageCount, (periodicMessageCount / uint64(statsInterval*(statsCounter))))))
				//periodicMessageCount = 0
			}
			connIndex = 1
			statsCounter++
		}
		//fmt.Printf("   > Endpoint %d: %s\n", endpointID, endpoint)
		statsFileMutex.Lock()
		statsOutFO.Write([]byte(fmtPrinter.Sprintf("  > %s : Endpoint : %s > Connection %d -> min: %d µs, max: %d µs, average: %d µs \n",
			time.Now().Format("2006-01-02 15:04:05"), endpoint, connIndex, minLatency, maxLatency, averageLatency)))
		statsFileMutex.Unlock()
		connIndex++
	}
}

//ExecuteCallFlow executes the call flow configured in the test configuration
//Closing testStopIndicator channel stops the test
func ExecuteCallFlow(testStopIndicator <-chan bool, clientErrorChannel chan<- string, testWaitGroup *sync.WaitGroup, statsFile *os.File) {
	nflogger.LogEntry()
	//fmt.Println(" > Test Started...")
	resetVariables()
	defer testWaitGroup.Done()
	numOfCallsInCallFlow := getNumberOfCallsInCallfow()
	loadParams := testconfig.TestConf.Client.LoadParameters

	if loadParams != nil {
		testDuration := time.Duration(loadParams.TestDurationInSec) * time.Second
		msgCount := (loadParams.DesiredTPSPerThread / numOfCallsInCallFlow)
		sleepTime := 1 * time.Second
		threadsPerConnection := loadParams.NumberOfThreads / loadParams.NumberOfConnections
		threadsPerEndPoint := loadParams.NumberOfThreads / len(loadParams.Endpoints)
		connectionsPerEndpoint := loadParams.NumberOfConnections / len(loadParams.Endpoints)
		var connLatencyChannel periodicLatencyChannels
		var endpointLatencyChannel periodicLatencyChannels
		var waitGroup sync.WaitGroup
		//Latency Channels for initial connection
		updateLatencyFields()
		endpointID := 1
		statsFile.Write([]byte(fmt.Sprintf("%s Test Started %s \n", strings.Repeat("=", 70), strings.Repeat("=", 70))))
		for i, connectionID := 0, 0; i < loadParams.NumberOfThreads; i++ {
			waitGroup.Add(1)
			//endpointConnectionID := 1
			if i == 0 {
				connLatencyChannel = createLatencyChannles()
				endpointLatencyChannel = createLatencyChannles()
				go computeLatencyStats(connLatencyChannel, endpointLatencyChannel)
				go writeEndPointLatencies(endpointID, connectionID, endpointLatencyChannel, statsFile)
			} else if i != 0 && i%threadsPerConnection == 0 && i%threadsPerEndPoint == 0 {
				connectionID++
				endpointID++
				connLatencyChannel = createLatencyChannles()
				endpointLatencyChannel = createLatencyChannles()
				go computeLatencyStats(connLatencyChannel, endpointLatencyChannel)
				go writeEndPointLatencies(endpointID, connectionID, endpointLatencyChannel, statsFile)
			} else if i != 0 && i%threadsPerConnection == 0 {
				connectionID++
				connLatencyChannel = createLatencyChannles()
				go computeLatencyStats(connLatencyChannel, endpointLatencyChannel)
			}
			endpointConnectionID := connectionID % connectionsPerEndpoint
			headerStore := make(map[string]string)
			bodyStore := make(map[string]string)
			go executeload(connectionID, endpointConnectionID, msgCount, sleepTime, testDuration,
				connLatencyChannel, headerStore, bodyStore, testStopIndicator, clientErrorChannel, &waitGroup)
		}
		waitGroup.Wait()
		logStatsToFile(statsFile)

	} else {
		headerStore := make(map[string]string)
		bodyStore := make(map[string]string)
		_, err := executeCallFlow(test.Connections[0], headerStore, bodyStore)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			clientErrorChannel <- err.Error()
			return
		}
		statsFile.Write([]byte("\n*********Test Statistics*********"))
		statsFile.Write([]byte("   -> Test Type     : Functional"))
		statsFile.Write([]byte("   -> Result        : Success"))
		statsFile.Write([]byte("*********************************"))
	}
	nflogger.LogExit()
}

func logStatsToFile(statsFile *os.File) {
	if isClientFailed {
		logFailure(statsFile)
		return
	}
	logStats(statsFile)
}

func logFailure(statsFile *os.File) {
	fmtPrinter := message.NewPrinter(language.English)
	loadParams := testconfig.TestConf.Client.LoadParameters
	testDuration := time.Duration(loadParams.TestDurationInSec) * time.Second
	statsFile.Write([]byte("\nTest Statistics:\n"))
	statsFile.Write([]byte("   > Test Type     : Performance\n"))
	statsFile.Write([]byte("   > Result        : Failed\n"))
	statsFile.Write([]byte(fmtPrinter.Sprintln("   > Test Duration :", testDuration)))
	statsFile.Write([]byte(fmtPrinter.Sprintln("   > Time Elapsed  :", time.Since(testStartTime))))
	statsFile.Write([]byte(fmtPrinter.Sprintln("   > Messages Sent :", messageCount)))
	if uint64(time.Since(testStartTime).Seconds()) == 0 {
		statsFile.Write([]byte(fmtPrinter.Sprintln("   > TPS           :", 0)))
	} else {
		statsFile.Write([]byte(fmtPrinter.Sprintln("   > TPS           :", messageCount/uint64(time.Since(testStartTime).Seconds()))))
	}
}

func logStats(statsFile *os.File) {
	fmtPrinter := message.NewPrinter(language.English)
	loadParams := testconfig.TestConf.Client.LoadParameters
	testDuration := time.Duration(loadParams.TestDurationInSec) * time.Second
	connectionsPerEndpoint := loadParams.NumberOfConnections / len(loadParams.Endpoints)
	statsFile.Write([]byte("\nTest Statistics:\n"))
	statsFile.Write([]byte("   > Test Type     : Performance\n"))
	statsFile.Write([]byte("   > Result        : Success\n"))
	statsFile.Write([]byte(fmtPrinter.Sprintln("   > Test Duration :", testDuration)))
	statsFile.Write([]byte(fmtPrinter.Sprintln("   > Time Elapsed  :", time.Since(testStartTime))))
	statsFile.Write([]byte(fmtPrinter.Sprintln("   > Messages Sent :", messageCount)))
	if uint64(time.Since(testStartTime).Seconds()) == 0 {
		statsFile.Write([]byte(fmtPrinter.Sprintln("   > TPS           :", 0)))
	} else {
		statsFile.Write([]byte(fmtPrinter.Sprintln("   > TPS           :", messageCount/uint64(time.Since(testStartTime).Seconds()))))
	}

	statsFile.Write([]byte("Latencies:\n"))
	endpointCounter := 1
	for endpoint, endpointLatency := range latencyStats {
		//fmt.Printf("   > Endpoint %d: %s\n", endpointCounter, endpoint)
		statsFile.Write([]byte(fmt.Sprintf("   > Endpoint %d: %s\n", endpointCounter, endpoint)))
		index := 1
		rollUpMinLatency, rollUpMaxLatency, rollUpOverallLatency := int64(0), int64(0), int64(0)
		for _, connectionLatency := range endpointLatency {
			min := helper.GetMinElementInArray(connectionLatency["min"])
			max := helper.GetMaxElementInArray(connectionLatency["max"])
			average := helper.GetAverageOfArrayElements(connectionLatency["average"])
			rollUpOverallLatency += average
			if index == 1 {
				rollUpMinLatency = min
				rollUpMaxLatency = max

			} else {
				if min < rollUpMinLatency {
					rollUpMinLatency = min
				}
				if max > rollUpMaxLatency {
					rollUpMaxLatency = max
				}
			}
			//fmtPrinter.Printf("      > Connection %d -> min: %d µs, max: %d µs, average: %d µs \n", index, min, max, average)
			statsFile.Write([]byte(fmtPrinter.Sprintf("      > Connection %d -> min: %d µs, max: %d µs, average: %d µs \n", index, min, max, average)))
			index++
		}
		// fmtPrinter.Printf("      > Aggregated   -> min: %d µs, max: %d µs, average: %d µs \n",
		// 	rollUpMinLatency, rollUpMaxLatency, (rollUpOverallLatency / int64(connectionsPerEndpoint)))
		statsFile.Write([]byte(fmtPrinter.Sprintf("      > Aggregated   -> min: %d µs, max: %d µs, average: %d µs \n",
			rollUpMinLatency, rollUpMaxLatency, (rollUpOverallLatency / int64(connectionsPerEndpoint)))))
		endpointCounter++
	}
}

//ExecuteClientCall executes the call (Request-Response) according to the configs of callConfig
// In case of any failure returns error.
func ExecuteClientCall(connectionInstance test.Connection, callConfig testconfig.Call, headerStore, bodyStore map[string]string) ([]int64, error) {
	nflogger.LogEntry()
	nflogger.LogInfo("Executing client call with call count -", callConfig.Count)
	var callLatencies []int64
	for index := 0; index < callConfig.Count; index++ {
		response, responseLatency, err := sendRequest(connectionInstance, callConfig.Send, headerStore, bodyStore)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return nil, err
		}
		callLatencies = append(callLatencies, responseLatency)
		err = ValidateResponseAtClient(callConfig.Receive.Validate, response)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return nil, err
		}

		if callConfig.Receive.CallbackID != "" {
			callbackFunc := test.CallbackMap[callConfig.Receive.CallbackID]
			_, _, _, err = callbackFunc(callConfig.Receive.MessageID, response.Header, response.Body)
			if err != nil {
				return nil, err
			}
		}

		err = storeHeader(response.Header, callConfig.Receive.MessageID, callConfig.Receive.Store.Header, headerStore)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return nil, err
		}

		err = storeBody(response.Body, callConfig.Receive.MessageID, callConfig.Receive.Store.Body, bodyStore)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return nil, err
		}
	}
	nflogger.LogExit()
	return callLatencies, nil
}

func sendRequest(connectionInstance test.Connection, sendConfig testconfig.Send, headerStore, bodyStore map[string]string) (http02.ResponseAttributes, int64, error) {
	nflogger.LogEntry()
	reqBody := requestBodies[sendConfig.MessageID]
	var err error
	//TODO If restore is configured rendering template in test case with callback function
	//will not work.
	if sendConfig.Restore.Body != nil {
		reqBody, err = restoreBody(reqBody, sendConfig.Restore.MessageID, sendConfig.Restore.Body, bodyStore)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return http02.ResponseAttributes{}, 0, err
		}
	}

	var endpoint string
	if connectionInstance.EndPoint == "" {
		endpoint = sendConfig.URL
	} else {
		endpoint = connectionInstance.EndPoint
	}

	endpoint, err = counters.GetUpdatedEndpointWithCounter(endpoint)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return http02.ResponseAttributes{}, 0, err
	}

	nflogger.LogInfo("Sending", sendConfig.Method, "request to URI ", endpoint,
		"Message ID is -", sendConfig.MessageID)
	nflogger.LogDebug("Message ID -", sendConfig.MessageID, "\nURL -", endpoint,
		"\nMethod -", sendConfig.Method, "\nRequest body file -",
		sendConfig.HTTPBodyTemplate, "\nRequest Header -", sendConfig.Header)

	var header map[string]string

	if sendConfig.Header != nil {
		//TODO Deep cpying the map, if the original map is used it will lead to concurrent map axis from multiple threads.
		//Discuss if any better way
		header = mapDeepCopy(sendConfig.Header)
	} else {
		header = make(map[string]string)
	}

	err = restoreHeader(header, sendConfig.Restore.MessageID,
		sendConfig.Restore.Header, headerStore)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return http02.ResponseAttributes{}, 0, err
	}

	queryParams := sendConfig.QueryParameters

	reqBody, err = counters.GetUpdatedHTTPBodyWithCounters(reqBody)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return http02.ResponseAttributes{}, 0, err
	}

	header, err = counters.GetUpdateHeaderWithCounters(header)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return http02.ResponseAttributes{}, 0, err
	}

	queryParams, err = counters.GetUpdatedQueryParametersWithCounters(queryParams)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return http02.ResponseAttributes{}, 0, err
	}

	httpHeader := convertToHTTPHeader(header)

	if sendConfig.CallbackID != "" {
		callbackFunc := test.CallbackMap[sendConfig.CallbackID]
		httpHeader, reqBody, queryParams, err = callbackFunc(sendConfig.MessageID, httpHeader, reqBody, queryParams)
		if err != nil {
			return http02.ResponseAttributes{}, 0, err
		}
	}

	startTime := time.Now()
	response, err := http02.SendRequest(connectionInstance.Instance, strings.ToUpper(sendConfig.Method), endpoint,
		httpHeader, []byte(reqBody), queryParams)
	responseLatency := time.Since(startTime).Microseconds()
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return http02.ResponseAttributes{}, 0, err
	}
	nflogger.LogExit()
	return response, responseLatency, err
}

func mapDeepCopy(originalMap map[string]string) map[string]string {
	targetMap := make(map[string]string)
	for key, value := range originalMap {
		targetMap[key] = value
	}
	return targetMap
}

func convertToHTTPHeader(header map[string]string) http.Header {
	var httpHeader = make(http.Header)
	for headerField, headerValue := range header {
		httpHeader.Set(headerField, headerValue)

	}
	return httpHeader
}

//storeHeader stores the given header fields into global variable 'HeaderStore'.
func storeHeader(header http.Header, msgID string, fieldsToStore []string, headerStore map[string]string) error {
	nflogger.LogEntry()
	if fieldsToStore == nil {
		nflogger.LogDebug("Configuration not found for storing message header fields. Skipping the store.")
		nflogger.LogExit()
		return nil
	}
	for _, storeField := range fieldsToStore {
		storeField := textproto.CanonicalMIMEHeaderKey(storeField)
		if storeValue, ok := header[storeField]; ok {
			storeValueStr := strings.Join(storeValue, "")
			storeInto := msgID + "-" + storeField
			headerStore[storeInto] = storeValueStr
			nflogger.LogInfo("Header field -", storeField, ":", storeValue, "is stored into -", storeInto)
		} else {
			err := customerror.HeaderFieldNotPresent(storeField)
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return err
		}
	}
	nflogger.LogExit()
	return nil
}

//storeBody stores the given json  body fields into global variable 'BodyStore'.
func storeBody(body, msgID string, fieldsToStore []string, bodyStore map[string]string) error {
	nflogger.LogEntry()
	if fieldsToStore == nil {
		nflogger.LogDebug("Configuration not found for storing message body fields. Skipping the store.")
		nflogger.LogExit()
		return nil
	}
	flattenedBody, err := helper.GetFlattenedJSONFromString(body)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return err
	}
	for _, storeField := range fieldsToStore {
		if storeValue, ok := flattenedBody[storeField]; ok {
			storeInto := msgID + "-" + storeField
			bodyStore[storeInto] = storeValue.(string)
			nflogger.LogInfo("Body field -", storeField, ":", storeValue, "is stored into", storeInto)
		} else {
			err := customerror.BodyFieldNotPresent(storeField)
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return err
		}
	}
	nflogger.LogExit()
	return nil
}

//restoreHeader - Restore the given header fields into the header p[assed.
func restoreHeader(header map[string]string, msgID string, fieldsToRestore, headerStore map[string]string) error {
	nflogger.LogEntry()
	if fieldsToRestore == nil {
		nflogger.LogDebug("Configuration not found for re-storing message header fields. Skipping the restore.")
		nflogger.LogExit()
		return nil
	}
	for restoreKey, restoreField := range fieldsToRestore {
		restoreKey := msgID + "-" + restoreKey
		if restoreValue, ok := headerStore[restoreKey]; ok {
			header[restoreField] = restoreValue
		} else {
			err := customerror.KeyNotPresent(restoreKey)
			nflogger.LogError(restoreKey, "is not storesd to restore.")
			nflogger.LogExit()
			return err
		}
	}
	nflogger.LogExit()
	return nil
}

func restoreBody(template, msgID string, fieldsToRestore, bodyStore map[string]string) (string, error) {
	nflogger.LogEntry()
	var config = make(map[string]string)
	for restoreKey, restoreField := range fieldsToRestore {
		restoreKey := msgID + "-" + restoreKey
		if restoreValue, ok := bodyStore[restoreKey]; ok {
			config[restoreField] = restoreValue
		} else {
			err := customerror.KeyNotPresent(restoreKey)
			nflogger.LogError(restoreKey, "is not stored to restore.")
			nflogger.LogExit()
			return "", err
		}
	}
	content, err := helper.RenderTemplateFromString(template, config)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return "", err
	}

	nflogger.LogExit()
	return content, nil
}
