package call

import (
	"errors"
	"fmt"
	"net/http"
	"net/textproto"
	"net/url"
	customerror "nf-simulator/customerr"
	"nf-simulator/helper"
	"nf-simulator/http02"
	"nf-simulator/nflogger"
	"nf-simulator/testconfig"
	"strings"
)

//ValidateHeader - Compares all the header fields expected are present in the received header.
//If fields are missing or field values are not equal returns false.
func ValidateHeader(expectedHeader map[string]string, receivedHeader http.Header) (bool, error) {
	nflogger.LogEntry()
	if expectedHeader == nil {
		nflogger.LogDebug("Header validation not configured(validateHeader).")
		nflogger.LogExit()
		return true, nil
	}
	nflogger.LogInfo("Validating received message headers.")
	for header, expectedValue := range expectedHeader {
		header := textproto.CanonicalMIMEHeaderKey(header)
		if receivedValue, ok := receivedHeader[header]; ok {
			receivedValueString := strings.Join(receivedValue, "")
			if expectedValue != receivedValueString {
				nflogger.LogError("Received header value for header -",
					header, "does not math the expected value.\n", "Expected -",
					expectedValue, "Received -", receivedValueString)
				nflogger.LogExit()
				return false, nil
			}
			nflogger.LogDebug("Received header value for header -", header,
				"mathes the expected value.\n", "Expected -", expectedValue,
				"Received -", receivedValueString)
		} else {
			nflogger.LogError("Expected header -", header,
				"is not present in the received header.")
			nflogger.LogExit()
			return false, nil
		}
	}
	nflogger.LogExit()
	return true, nil
}

//ValidateQueryParameters - Compares all the query fields expected are present in the received query parameters.
//If fields are missing or field values are not equal returns false.
func ValidateQueryParameters(expectedQueryParams map[string]string, receivedQueryParams url.Values) (bool, error) {
	nflogger.LogEntry()
	if expectedQueryParams == nil {
		nflogger.LogDebug("Query parameter validation not configured(validateHeader).")
		nflogger.LogExit()
		return true, nil
	}
	nflogger.LogInfo("Validating request queryparmeters.")
	for query, expectedValue := range expectedQueryParams {
		//header := textproto.CanonicalMIMEHeaderKey(header)
		if receivedValue, ok := receivedQueryParams[query]; ok {
			receivedValueString := strings.Join(receivedValue, "")
			if expectedValue != receivedValueString {
				nflogger.LogError("Received query value for - ",
					query, "does not math the expected value.\n", "Expected - ",
					expectedValue, "Received -", receivedValueString)
				nflogger.LogExit()
				return false, nil
			}
			nflogger.LogDebug("Received query value for -", query,
				"mathes the expected value.\n", "Expected -", expectedValue,
				"Received -", receivedValueString)
		} else {
			nflogger.LogError("Expected query -", query,
				"is not present in the received query parameters.")
			nflogger.LogExit()
			return false, nil
		}
	}
	nflogger.LogExit()
	return true, nil
}

//ValidateStatusCode compares the expected status code with the received status code
//If not matching retuns false.
func ValidateStatusCode(expectedStatusCodes []int, receivedStatusCode int) bool {
	if expectedStatusCodes != nil {
		for _, expectedStatusCode := range expectedStatusCodes {
			if expectedStatusCode == receivedStatusCode {
				return true
			}
		}
		return false
	}
	return true
}

//ValidateBody - Compares all the Body fields expected are present in the received Body.
//If fields are missing or field values are not equal returns false.
func ValidateBody(expectedBodyFields map[string]string, body string) (bool, error) {
	nflogger.LogEntry()
	if expectedBodyFields == nil {
		nflogger.LogInfo("Message body validation is not configured (validateBody).")
		nflogger.LogExit()
		return true, nil
	}
	flattenedBody, err := helper.GetFlattenedJSONFromString(body)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return false, err
	}
	nflogger.LogInfo("Validating received message body")
	for bodyField, expectedValue := range expectedBodyFields {
		if receivedValue, ok := flattenedBody[bodyField]; ok {
			if expectedValue != receivedValue {
				nflogger.LogError("Received Body value for field -", bodyField,
					"does not match the recieved.", "Expected value -", expectedValue,
					"Received value", receivedValue)
				nflogger.LogExit()
				return false, nil
			}
		} else {
			nflogger.LogError("Expected body field -", bodyField,
				"does not present in the received message body.")
			nflogger.LogExit()
			return false, nil
		}
	}
	nflogger.LogExit()
	return true, nil
}

//ValidateResponseAtClient - Validatesd the client response and retuns error in case of failure
func ValidateResponseAtClient(validateConf testconfig.Validate, response http02.ResponseAttributes) error {
	nflogger.LogEntry()
	ok, err := ValidateHeader(validateConf.Header, response.Header)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return err
	}
	if !ok {
		nflogger.LogError(customerror.ErrHeaderNotMatching.Error())
		nflogger.LogExit()
		return customerror.ErrHeaderNotMatching
	}

	ok, err = ValidateBody(validateConf.Body, response.Body)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return err
	}
	if !ok {
		nflogger.LogError(customerror.ErrBodyFieldNotMatching.Error())
		nflogger.LogExit()
		return customerror.ErrBodyFieldNotMatching
	}

	ok = ValidateStatusCode(validateConf.StatusCode, response.ResponseCode)
	if !ok {
		err := fmt.Sprintln(customerror.ErrStatusCodeNotMatching.Error(), ". Expected is ", validateConf.StatusCode, ", Received is ", response.ResponseCode)
		nflogger.LogError(err)
		nflogger.LogExit()
		return errors.New(err)
	}
	nflogger.LogExit()
	return nil
}
