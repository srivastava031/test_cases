package testconfig

import (
	"errors"
	"nf-simulator/helper"
	"nf-simulator/nflogger"
)

/*
//ValidateTestConfig validates the test configuration fields.
//If the fields configured are not valid, returns false, else returns true.
func ValidateTestConfig(configFile string) (bool, error) {
	nflogger.LogEntry()
	nflogger.LogInfo("Validating test configurations")
	clientInstanceConfig, err := GetInstanceConfig(configFile, "client")
	if err != nil {
		nflogger.LogExit()
		nflogger.LogError(err.Error())
		return false, err
	}
	serverInstanceConfig, err := GetInstanceConfig(configFile, "Server")
	if err != nil {
		nflogger.LogExit()
		nflogger.LogError(err.Error())
		return false, err
	}
	ok, err := validateInstanceConfig(clientInstanceConfig, serverInstanceConfig)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return false, err
	}
	if !ok {
		nflogger.LogExit()
		return false, nil
	}

	nflogger.LogExit()
	return true, nil
}

func validateInstanceConfig(clientInstanceConfig, serverInstanceConfig []map[string]string) (bool, error) {
	nflogger.LogEntry()
	nflogger.LogInfo("Validating instance configuration")
	if clientInstanceConfig == nil {
		nflogger.LogDebug("Client instances are not configured for the test. skipping Client instance validation")
	} else {
		ok, err := validateClientInstanceConfig(clientInstanceConfig)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return false, err
		}
		if !ok {
			nflogger.LogExit()
			return false, nil
		}
	}

	if serverInstanceConfig == nil {
		nflogger.LogDebug("Server instances are not configured for the test. skipping server instance validation")
	} else {
		ok, err := validateServerInstanceConfig(serverInstanceConfig)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return false, err
		}
		if !ok {
			nflogger.LogExit()
			return false, nil
		}
	}
	nflogger.LogExit()
	return true, nil
}

func validateClientInstanceConfig(clientInstanceConfig []map[string]string) (bool, error) {
	nflogger.LogEntry()
	nflogger.LogInfo("Validating client instance config")
	for _, config := range clientInstanceConfig {
		if !helper.IsValidIP(config["ip"]) {
			nflogger.LogError("Client instance configuration validation failed. Invalid IP configured", config["ip"])
			nflogger.LogExit()
			return false, nil
		}
		//No validation for port required
	}
	nflogger.LogExit()
	return true, nil
}

func validateServerInstanceConfig(serverInstanceConfig []map[string]string) (bool, error) {
	nflogger.LogEntry()
	nflogger.LogInfo("Validating Server instance config")
	for _, config := range serverInstanceConfig {
		if !helper.IsValidIP(config["ip"]) {
			nflogger.LogError("Server instance configuration validation failed. Invalid IP configured", config["ip"])
			nflogger.LogExit()
			return false, nil
		}
		//No validation for port number required
	}
	nflogger.LogExit()
	return true, nil
}


func validateSendRequestConfig(callConfig string) (bool, error) {
	requestMethodsSupported := []string{"POST", "GET"}
	configSendRequest, err := GetClientSendRequestConfig(callConfig)
	if err != nil {
		return false, err
	}
	helper.IsElementInSlice(configSendRequest.MethodName)
}
*/

//ValidateTestConfig validates the test configuration fields.
//If the fields configured are not valid, returns false, else returns true.
func ValidateTestConfig(testConfFile string) error {
	nflogger.LogEntry()
	nflogger.LogInfo("Validating test configurations")
	isValid, err := helper.IsValidJSONFile(testConfFile)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return err
	}
	if !isValid {
		err = errors.New("Invalid JSON File : " + testConfFile)
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return err
	}
	err = validateLoadParmeters()
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return err
	}
	return nil
}

func validateLoadParmeters() error {
	loadParams := TestConf.Client.LoadParameters
	if loadParams != nil {
		if !((loadParams.NumberOfThreads >= loadParams.NumberOfConnections) && (loadParams.NumberOfConnections >= len(loadParams.Endpoints))) {
			err := errors.New("Test Config Error: Not matching precondition: Number of Threads >= Number of Connections >= Number of Endpoints")
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return err
		}
		if loadParams.NumberOfThreads%loadParams.NumberOfConnections != 0 {
			err := errors.New("Test Config Error: numberOfThreads should be factor of numOfConnection")
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return err
		} else if loadParams.NumberOfConnections%len(loadParams.Endpoints) != 0 {
			err := errors.New("Test Config Error: numOfConnection should be factor of number of Endpoints")
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return err
		}
	}
	return nil
}
