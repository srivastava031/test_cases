package testconfig

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
)

var TestConf TestConfig

type TLSConfig struct {
	GeneratePreMasterSecretLog                    bool
	CertificateFile, CertificatePassword, KeyFile string
	TrustedCAs                                    []string
}

type LoadParameters struct {
	NumberOfThreads, NumberOfConnections   int
	Endpoints                              []string
	DesiredTPSPerThread, TestDurationInSec int
}

type Counter struct {
	Name, Type                        string
	StartAt, EndAt                    string
	IncrementBy                       int
	TrackIndependtlyForEachConnection bool
	ResetAfterEachIterationOfCallFlow bool
}

type Restore struct {
	MessageID    string
	Header, Body map[string]string
}

type Send struct {
	MessageID, Method, URL, CallbackID string
	Header                             map[string]string
	HTTPBodyTemplate                   string
	QueryParameters                    map[string]string
	Restore                            Restore
}

type Validate struct {
	StatusCode   []int
	Header, Body map[string]string
}

type Store struct {
	Header, Body []string
}

type Receive struct {
	MessageID, CallbackID string
	Validate              Validate
	Store                 Store
}

type Call struct {
	Count   int
	Send    Send
	Receive Receive
}

type Client struct {
	ForceHTTP1      bool
	EnableTLS       bool
	ResponseTimeout uint32
	TLSConfig       TLSConfig
	LoadParameters  *LoadParameters
	CallFlow        []Call
}

type Instance struct {
	IP          string
	Port        int
	ResourceIds []string
}
type ValidateRequest struct {
	QueryParameters, Header, Body map[string]string
}

type Request struct {
	CallbackID string
	Validate   ValidateRequest
}

type Response struct {
	StatusCode       int
	Header           map[string]string
	HttpBodyTemplate string
	CallbackID       string
}

type Resource struct {
	ResourceID, MessageID, ResourcePath, HttpMethod string
	Request                                         Request
	Response                                        Response
}

type Server struct {
	ServerUpDurationInSec int
	EnableTLS             bool
	MaxConcurrentStreams  uint32
	TLSConfig             TLSConfig
	Instances             []Instance
	Resources             []Resource
}

type TestConfig struct {
	Counters []Counter
	Client   Client
	Server   Server
}

func InitialiseTestConfig(testConfigFile string) {
	var testconf TestConfig
	testConfigContent, err := ioutil.ReadFile(testConfigFile)
	if err != nil {
		fmt.Print(err)
	}

	json.Unmarshal(testConfigContent, &testconf)
	TestConf = testconf
}
