package http02

import (
	"bytes"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"io"
	"io/ioutil"
	"net"
	"net/http"
	"nf-simulator/config"
	"nf-simulator/nflogger"
	"nf-simulator/testconfig"
	"strings"
	"time"

	"golang.org/x/crypto/pkcs12"

	"golang.org/x/net/http2"
)

//ResponseAttributes - contains
//1. Response Code
//2. Response Header
//3. Response body
type ResponseAttributes struct {
	ResponseCode int
	Header       http.Header
	Body         string
}

func createClientTLSConfig(keyLogWriter io.Writer) (*tls.Config, error) {
	var rootCAs *x509.CertPool
	var clientTLScertificates tls.Certificate
	var err error
	var tlsConfig *tls.Config
	trustedCAs := testconfig.TestConf.Client.TLSConfig.TrustedCAs
	certificateFile := testconfig.TestConf.Client.TLSConfig.CertificateFile
	certificatePassword := testconfig.TestConf.Client.TLSConfig.CertificatePassword
	keyFile := testconfig.TestConf.Client.TLSConfig.KeyFile
	if trustedCAs == nil {
		rootCAs = nil
	} else {
		rootCAs = x509.NewCertPool()
		for _, ca := range trustedCAs {
			caContent, err := ioutil.ReadFile(ca)
			if err != nil {
				nflogger.LogError(err.Error())
				nflogger.LogExit()
				return nil, err
			}
			ok := rootCAs.AppendCertsFromPEM(caContent)
			if !ok {
				err = errors.New("Failed to Parse CA certificates")
				nflogger.LogError(err.Error())
				nflogger.LogExit()
				return nil, err
			}
		}
	}

	if (strings.HasSuffix(certificateFile, ".pfx") ||
		strings.HasSuffix(certificateFile, ".p12")) &&
		keyFile == "" {
		bytes, err := ioutil.ReadFile(certificateFile)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return nil, err
		}
		key, cert, err := pkcs12.Decode(bytes, certificatePassword)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return nil, err
		}
		clientTLScertificates = tls.Certificate{
			Certificate: [][]byte{cert.Raw},
			PrivateKey:  key,
			Leaf:        cert,
		}
	} else if (strings.HasSuffix(certificateFile, ".pem") ||
		strings.HasSuffix(certificateFile, ".cert") ||
		strings.HasSuffix(certificateFile, ".crt")) &&
		keyFile != "" {
		clientTLScertificates, err = tls.LoadX509KeyPair(certificateFile, keyFile)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return nil, err
		}
	} else if certificateFile != "" && keyFile != "" {
		err := errors.New("The client certificate should be in .pem(.cert/.crt) or .pfx or .p12 format")
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return nil, err
	}

	if testconfig.TestConf.Client.TLSConfig.GeneratePreMasterSecretLog == true {
		tlsConfig = &tls.Config{
			KeyLogWriter:       keyLogWriter,
			InsecureSkipVerify: true,
			RootCAs:            rootCAs,
			Certificates:       []tls.Certificate{clientTLScertificates},
		}
		nflogger.LogExit()
		return tlsConfig, nil
	}
	tlsConfig = &tls.Config{
		InsecureSkipVerify: true,
		RootCAs:            rootCAs,
		Certificates:       []tls.Certificate{clientTLScertificates},
	}
	nflogger.LogExit()
	return tlsConfig, nil
}

//CreateH2Client creates HTTP2 request and returns the created instance
func CreateH2Client(keyLogWriter io.Writer) (*http.Client, error) {
	nflogger.LogEntry()
	nflogger.LogInfo("Creating client instance")

	var responseTimeout uint32

	if testconfig.TestConf.Client.ResponseTimeout == 0 {
		responseTimeout = 5
	} else {
		responseTimeout = testconfig.TestConf.Client.ResponseTimeout
	}

	if testconfig.TestConf.Client.EnableTLS && testconfig.TestConf.Client.ForceHTTP1 == true {
		tlsConfig, err := createClientTLSConfig(keyLogWriter)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return nil, err
		}
		client := &http.Client{
			Transport: &http.Transport{
				TLSClientConfig: tlsConfig,
			},
			Timeout: time.Duration(responseTimeout) * time.Second,
		}
		nflogger.LogInfo("Created client instance")
		nflogger.LogExit()
		return client, nil

	}
	if testconfig.TestConf.Client.EnableTLS && testconfig.TestConf.Client.ForceHTTP1 != true {
		tlsConfig, err := createClientTLSConfig(keyLogWriter)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return nil, err
		}
		client := &http.Client{
			Transport: &http2.Transport{
				TLSClientConfig: tlsConfig,
				AllowHTTP:       true,
				// DialTLS: func(network, addr string, cfg *tls.Config) (net.Conn, error) {
				// 	return tls.Dial(network, addr, tlsConfig)
				// },
			},
			Timeout: time.Duration(responseTimeout) * time.Second,
		}
		nflogger.LogInfo("Created client instance")
		nflogger.LogExit()
		return client, nil
	}
	if testconfig.TestConf.Client.EnableTLS != true && testconfig.TestConf.Client.ForceHTTP1 == true {
		client := &http.Client{
			Timeout: time.Duration(responseTimeout) * time.Second,
		}
		nflogger.LogInfo("Created client instance")
		nflogger.LogExit()
		return client, nil
	}

	client := &http.Client{
		Transport: &http2.Transport{
			AllowHTTP: true,
			DialTLS: func(network, addr string, cfg *tls.Config) (net.Conn, error) {
				return net.Dial(network, addr)
			},
		},
		Timeout: time.Duration(responseTimeout) * time.Second,
	}
	nflogger.LogInfo("Created client instance")
	nflogger.LogExit()
	return client, nil
}

//SendRequest sends the request to the URL given
func SendRequest(client *http.Client, method string, url string, header http.Header, body []byte, queryParams map[string]string) (ResponseAttributes, error) {
	nflogger.LogEntry()
	nflogger.LogInfo("Sending", method, "request to URI", url)
	request, err := http.NewRequest(method, url, bytes.NewReader(body))
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return ResponseAttributes{}, err
	}

	query := request.URL.Query()
	if queryParams != nil {
		for key, value := range queryParams {
			query.Add(key, value)
		}
	}
	if config.ProductConfig.Encoding.DisableFormEncoding == true && queryParams != nil {
		request.URL.RawQuery = strings.ReplaceAll(query.Encode(), "+", "%20")
	} else if queryParams != nil {
		request.URL.RawQuery = query.Encode()
	}
	if header != nil {
		for key, value := range header {
			//TODO Use req.Header.Set
			request.Header[key] = value
		}
	}

	/*
		ctx, cancel := context.WithTimeout(context.Background(), timeout*time.Second)
		defer cancel()
		request = request.WithContext(ctx)
	*/

	response, err := client.Do(request)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return ResponseAttributes{}, err
	}

	respStatusCode := getResponseStatusCode(response)
	respHeader := getResponseHeader(response)
	respBody, err := getResponseBody(response)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return ResponseAttributes{}, err
	}
	nflogger.LogInfo("Status code of the received message -", respStatusCode)
	nflogger.LogExit()
	return ResponseAttributes{ResponseCode: respStatusCode, Header: respHeader, Body: respBody}, nil
}

//getResponseStatusCode fetches the header from http response and
//returns
func getResponseStatusCode(response *http.Response) int {
	nflogger.LogEntry()
	nflogger.LogExit()
	return response.StatusCode
}

//getResponseHeader fetches the header from http response and
//returns
func getResponseHeader(response *http.Response) http.Header {
	nflogger.LogEntry()
	nflogger.LogExit()
	return response.Header
}

//getResponseBody fetches the body from http response and
//returns
func getResponseBody(response *http.Response) (string, error) {
	nflogger.LogEntry()
	body, err := ioutil.ReadAll(io.Reader(response.Body))
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return "", err
	}
	nflogger.LogExit()
	return string(body), nil
}
