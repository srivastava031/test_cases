package server

import (
	"crypto/tls"
	"crypto/x509"
	"errors"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"nf-simulator/nflogger"
	"nf-simulator/testconfig"
	"os"
	"strings"
	"sync"

	"github.com/gorilla/mux"
	"golang.org/x/crypto/pkcs12"
	"golang.org/x/net/http2"
	"golang.org/x/net/http2/h2c"
)

var serverInstances []*http.Server

func getServerTLSConfig(keyLogWriter io.Writer) (*tls.Config, error) {
	clientCAs := x509.NewCertPool()
	var serverTLScertificates tls.Certificate
	var err error
	config := testconfig.TestConf.Server.TLSConfig
	if config.TrustedCAs == nil {
		clientCAs = nil
	} else {
		for _, ca := range config.TrustedCAs {
			caContent, err := ioutil.ReadFile(ca)
			if err != nil {
				nflogger.LogError(err.Error())
				nflogger.LogExit()
				return nil, err
			}
			ok := clientCAs.AppendCertsFromPEM(caContent)
			if !ok {
				err = errors.New("Failed to Parse CA certificates")
				nflogger.LogError(err.Error())
				nflogger.LogExit()
				return nil, err
			}
		}
	}

	if (strings.HasSuffix(config.CertificateFile, ".pfx") ||
		strings.HasSuffix(config.CertificateFile, ".p12")) &&
		config.KeyFile == "" {
		bytes, err := ioutil.ReadFile(config.CertificateFile)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return nil, err
		}
		key, cert, err := pkcs12.Decode(bytes, config.CertificatePassword)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return nil, err
		}

		serverTLScertificates = tls.Certificate{
			Certificate: [][]byte{cert.Raw},
			PrivateKey:  key,
			Leaf:        cert,
		}

	} else if (strings.HasSuffix(config.CertificateFile, ".pem") ||
		strings.HasSuffix(config.CertificateFile, ".cert") ||
		strings.HasSuffix(config.CertificateFile, ".crt")) &&
		config.KeyFile != "" {
		serverTLScertificates, err = tls.LoadX509KeyPair(config.CertificateFile, config.KeyFile)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return nil, err
		}

	} else {
		err := errors.New("The server certificate should be in .pem(.cert/.crt) or .pfx or .p12 format")
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return nil, err
	}

	if config.GeneratePreMasterSecretLog == true {
		tlsConfig := &tls.Config{
			KeyLogWriter: keyLogWriter,
			ClientAuth:   tls.VerifyClientCertIfGiven,
			ClientCAs:    clientCAs,
			Certificates: []tls.Certificate{serverTLScertificates},
		}
		nflogger.LogExit()
		return tlsConfig, nil
	}
	tlsConfig := &tls.Config{
		ClientAuth:   tls.VerifyClientCertIfGiven,
		ClientCAs:    clientCAs,
		Certificates: []tls.Certificate{serverTLScertificates},
	}
	nflogger.LogExit()
	return tlsConfig, nil
}

func StartServerInstances(serverErrorChannel chan<- string, testWaitGroup *sync.WaitGroup) {
	defer testWaitGroup.Done()
	updateHandlers()
	var keyLogWriter io.Writer
	var err error
	var wg sync.WaitGroup
	if testconfig.TestConf.Server.TLSConfig.GeneratePreMasterSecretLog == true {
		keyLogWriter, err = os.OpenFile("server-ssl-key.log", os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0655)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			serverErrorChannel <- err.Error()
		}
	}
	var h2server *http2.Server
	maxConcurrentStreams := testconfig.TestConf.Server.MaxConcurrentStreams
	for index, instanceConfig := range testconfig.TestConf.Server.Instances {
		router := getRouter(instanceConfig.ResourceIds)
		listenerPort := fmt.Sprintf("%s:%d", instanceConfig.IP, instanceConfig.Port)
		if maxConcurrentStreams != 0 {
			h2server = &http2.Server{
				MaxConcurrentStreams: maxConcurrentStreams,
			}
		} else {
			h2server = &http2.Server{}
		}
		var server *http.Server
		if testconfig.TestConf.Server.EnableTLS {
			tlsConfig, err := getServerTLSConfig(keyLogWriter)
			if err != nil {
				nflogger.LogError(err.Error())
				nflogger.LogExit()
				serverErrorChannel <- err.Error()
			}
			server = &http.Server{
				Addr:      listenerPort,
				TLSConfig: tlsConfig,
				//TLSNextProto: make(map[string]func(*http.Server, *tls.Conn, http.Handler), 0),
				Handler: h2c.NewHandler(router, h2server),
			}
		} else {
			server = &http.Server{
				Addr:    listenerPort,
				Handler: h2c.NewHandler(router, h2server),
			}
		}

		serverInstances = append(serverInstances, server)
		nflogger.LogInfo(fmt.Sprintf("Server instance[%d] listenig on %s\n", index+1, listenerPort))
		wg.Add(1)
		go func(wg *sync.WaitGroup) {
			defer wg.Done()
			var err error
			//defer waitgroup.Done()
			if testconfig.TestConf.Server.EnableTLS {
				err = server.ListenAndServeTLS("", "")
			} else {
				err = server.ListenAndServe()
			}
			if err != http.ErrServerClosed && err != nil {
				nflogger.LogError("Server failed to listen : ", err)
				errMsg := fmt.Sprintf("Server failed to listen : %s", err)
				serverErrorChannel <- errMsg
			}
		}(&wg)

	}
	wg.Wait()
}

//CloseAllServerInstances Closes all the server instances.
func CloseAllServerInstances() {
	//ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer func() {
		//cancel()
		serverInstances = nil
	}()
	for _, instance := range serverInstances {
		instance.Close()
		// if err := instance.Shutdown(ctx); err == context.DeadlineExceeded {
		// 	nflogger.LogError("shutdown: halted active connections: ", err)
		// }
	}
}

func getRouter(resourceIDs []string) *mux.Router {
	router := mux.NewRouter().StrictSlash(true)
	for _, resourceID := range resourceIDs {
		var handler http.Handler
		handler = http.HandlerFunc(resources[resourceID].handler)
		router.
			Methods(strings.ToUpper(resources[resourceID].httpMethod)).
			Path(resources[resourceID].resourcePath).
			Name(resourceID).
			Handler(handler)
	}
	return router
}
