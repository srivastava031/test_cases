package server

import (
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"nf-simulator/call"
	"nf-simulator/counters"
	"nf-simulator/helper"
	"nf-simulator/nflogger"
	"nf-simulator/test"
	"nf-simulator/testconfig"
	"os"
	"strings"
)

type resourceDetails struct {
	handler                  func(w http.ResponseWriter, r *http.Request)
	resourcePath, httpMethod string
}

var resources = make(map[string]resourceDetails)

func getHandler(resourceConfig testconfig.Resource) func(w http.ResponseWriter, r *http.Request) {
	return func(w http.ResponseWriter, r *http.Request) {
		if resourceConfig.Request.CallbackID != "" {
			requestBody, _ := ioutil.ReadAll(r.Body)
			callbackFunc := test.CallbackMap[resourceConfig.Request.CallbackID]
			_, _, _, err := callbackFunc(resourceConfig.MessageID, r.Header, string(requestBody))
			if err != nil {
				nflogger.LogError(err.Error())
				nflogger.LogExit()
				fmt.Println(err.Error())
				os.Exit(1)
			}
		}

		if resourceConfig.Request.Validate.QueryParameters != nil {
			//Update the query parameters with the counters, if counters are defined.
			updatedQueryParams, err := counters.GetUpdatedQueryParametersWithCounters(resourceConfig.Request.Validate.QueryParameters)
			if err != nil {
				nflogger.LogError(err.Error())
				fmt.Println(err.Error())
				nflogger.LogExit()
				os.Exit(1)
			}
			//Validate the query parametrs received with the expected
			isValid, err := call.ValidateQueryParameters(updatedQueryParams, r.URL.Query())
			if err != nil {
				nflogger.LogError(err.Error())
				fmt.Println(err.Error())
				nflogger.LogExit()
				os.Exit(1)
			}
			if isValid != true {
				nflogger.LogError("Query Parameter validation failed for resourceID - ", resourceConfig.ResourceID)
				fmt.Println("Query Parameter validation failed for resourceID - ", resourceConfig.ResourceID)
				nflogger.LogExit()
				os.Exit(1)
			}
		}
		if resourceConfig.Request.Validate.Body != nil {
			requestBody, _ := ioutil.ReadAll(r.Body)
			isValid, err := call.ValidateBody(resourceConfig.Request.Validate.Body, string(requestBody))
			if err != nil {
				nflogger.LogError(err.Error())
				fmt.Println(err.Error())
				nflogger.LogExit()
				os.Exit(1)
			}
			if isValid != true {
				nflogger.LogError("Request body validation failed for resource", resourceConfig.ResourceID)
				fmt.Println("Request body validation failed for resource", resourceConfig.ResourceID)
				nflogger.LogExit()
				os.Exit(1)
			}
		}
		if resourceConfig.Request.Validate.Header != nil {
			isValid, err := call.ValidateHeader(resourceConfig.Request.Validate.Header, r.Header)
			if err != nil {
				nflogger.LogError(err.Error())
				fmt.Println(err.Error())
				nflogger.LogExit()
				os.Exit(1)
			}
			if isValid != true {
				nflogger.LogError("Request Header validation failed for resourceID - ", resourceConfig.ResourceID)
				fmt.Println("Request Header validation failed for resourceID - ", resourceConfig.ResourceID)
				nflogger.LogExit()
				os.Exit(1)
			}
		}

		var responseHeader map[string]string
		var responseBody string
		var err error
		if resourceConfig.Response.Header != nil {
			responseHeader, err = counters.GetUpdateHeaderWithCounters(resourceConfig.Response.Header)
			if err != nil {
				nflogger.LogError("Failed to update Header with counters for resourceID - ", resourceConfig.ResourceID)
				fmt.Println("Failed to update Header with counters for resourceID - ", resourceConfig.ResourceID)
				nflogger.LogExit()
				os.Exit(1)
			}
		}

		if resourceConfig.Response.HttpBodyTemplate != "" {
			responseBody, err = helper.ReadFile(resourceConfig.Response.HttpBodyTemplate)
			if err != nil {
				nflogger.LogError("Failed to read HttpBodyTemplate for resourceID - ", resourceConfig.ResourceID)
				fmt.Println("Failed to read HttpBodyTemplate for resourceID - ", resourceConfig.ResourceID)
				nflogger.LogExit()
				os.Exit(1)
			}
			responseBody, err = counters.GetUpdatedHTTPBodyWithCounters(responseBody)
			if err != nil {
				nflogger.LogError("Failed to update HttpBodyTemplate with counters for resourceID - ", resourceConfig.ResourceID)
				fmt.Println("Failed to update HttpBodyTemplate with counters for resourceID - ", resourceConfig.ResourceID)
				nflogger.LogExit()
				os.Exit(1)
			}

		}

		if resourceConfig.Response.CallbackID != "" {
			callbackFunc := test.CallbackMap[resourceConfig.Response.CallbackID]
			httpHeader := convertToHTTPHeader(responseHeader)
			httpHeader, responseBody, _, err := callbackFunc(resourceConfig.MessageID, httpHeader, responseBody)
			if err != nil {
				nflogger.LogError(err.Error())
				nflogger.LogExit()
				fmt.Println(err.Error())
				os.Exit(1)
			}
			for field, value := range httpHeader {
				val := strings.Join(value, "")
				w.Header().Set(field, val)
			}
			w.WriteHeader(resourceConfig.Response.StatusCode)
			io.WriteString(w, responseBody)
		} else {
			for field, value := range responseHeader {
				w.Header().Set(field, value)
			}
			w.WriteHeader(resourceConfig.Response.StatusCode)
			io.WriteString(w, responseBody)
		}
	}
}

func convertToHTTPHeader(header map[string]string) http.Header {
	var httpHeader = make(http.Header)
	for headerField, headerValue := range header {
		httpHeader.Set(headerField, headerValue)

	}
	return httpHeader
}

func updateHandlers() {
	//resources := map[string]resourceDetails
	for _, resourceConfig := range testconfig.TestConf.Server.Resources {
		handler := getHandler(resourceConfig)
		resources[resourceConfig.ResourceID] = resourceDetails{handler, resourceConfig.ResourcePath, resourceConfig.HttpMethod}
	}
}
