package exectest

import (
	"errors"
	"fmt"
	"nf-simulator/call"
	"nf-simulator/config"
	"nf-simulator/counters"
	"nf-simulator/helper"
	"nf-simulator/nflogger"
	"nf-simulator/server"
	"nf-simulator/test"
	"nf-simulator/testconfig"
	"os"
	"path"
	"sync"
	"time"
)

//testCaseStatus - to store the test case status.
//key: (sut-testsuite-testcase), value: ["Status", "Failure Ccause"]
//Here Status can be - IN_PROGRESS/STOPPED/FAILED/PASSED
//In case the test case fails, the list will have one more element i.e Failure Cause.
var testCaseStatus = make(map[string][]string)
var testcaseStopIndicator chan bool

//anyTestRunning - True value indicates currently some test is going on
var anyTestRunning bool

func initailaiseTest(testcasePath string) error {
	//TODO - Have to clean the test case at the end of test here.
	config.InitialiseProductConfig()
	testconfig.InitialiseTestConfig(helper.GetTestConfigFile(testcasePath))
	err := counters.InitialiseCounters()
	if err != nil {
		return err
	}
	nflogger.InitialiseLogger(path.Join(testcasePath, "logs"))
	call.StoreAllRequestBodies()
	return nil
}

//CheckIsAnyTestRunning Returns true if any test is running.
func CheckIsAnyTestRunning() bool {
	return anyTestRunning
}

//ExecuteTestcase executes current test case
func ExecuteTestcase(sut, testsuite, testcase string) {
	//TODO - Have to clean the test case at the end of test here.
	testcasePath := path.Join(config.TestPath, sut, testsuite, testcase)
	testIdentifier := fmt.Sprintf("%s-%s-%s", sut, testsuite, testcase)
	var testWaitGroup sync.WaitGroup
	testCaseStatus[testIdentifier] = []string{"IN_PROGRESS"}
	anyTestRunning = true
	err := initailaiseTest(testcasePath)
	if err != nil {
		testCaseStatus[testIdentifier] = []string{"FAILED", err.Error()}
		anyTestRunning = false
		return
	}
	err = testconfig.ValidateTestConfig(helper.GetTestConfigFile(testcasePath))
	if err != nil {
		testCaseStatus[testIdentifier] = []string{"FAILED", err.Error()}
		anyTestRunning = false
		return
	}

	loadParams := testconfig.TestConf.Client.LoadParameters
	//testErrorChannel is used to track any errors during test execution from the goroutines/threads.
	//This is required as we are using triggering executeLoad in goroutine.
	//The size is equal to number of threads, expecting the error from all the threads
	// in a rare condition.
	var clientErrorChannel chan string
	if loadParams != nil {
		clientErrorChannel = make(chan string, loadParams.NumberOfThreads)
	}
	clientErrorChannel = make(chan string)

	var serverErrorChannel chan string
	if testconfig.TestConf.Server.Instances != nil {
		serverErrorChannel = make(chan string, len(testconfig.TestConf.Server.Instances))
	}
	serverErrorChannel = make(chan string)

	testcaseStopIndicator = make(chan bool)

	statsOutFile, err := os.OpenFile(path.Join(testcasePath, config.StatsFile), os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0644)
	if err != nil {
		testCaseStatus[testIdentifier] = []string{"FAILED", err.Error()}
		return
	}
	defer statsOutFile.Close()

	if testconfig.TestConf.Server.Instances != nil {
		testWaitGroup.Add(1)
		go server.StartServerInstances(serverErrorChannel, &testWaitGroup)
		time.Sleep(500 * time.Millisecond)

	}

	if testconfig.TestConf.Client.CallFlow != nil {
		err := test.CreateInstances(helper.GetTestConfigFile(testcasePath))
		if err != nil {
			testCaseStatus[testIdentifier] = []string{"FAILED", err.Error()}
			anyTestRunning = false
			return
		}

		testWaitGroup.Add(1)
		go call.ExecuteCallFlow(testcaseStopIndicator, clientErrorChannel, &testWaitGroup, statsOutFile)
	}

	testWaitGroup.Add(1)

	go monitorTest(testIdentifier, testcaseStopIndicator, clientErrorChannel, serverErrorChannel, &testWaitGroup)

	testWaitGroup.Wait()
}

func monitorTest(testIdentifier string, testcaseStopIndicator chan bool,
	clientErrorChannel, serverErrorChannel chan string, waitGroup *sync.WaitGroup) {
	defer waitGroup.Done()
	startTime := time.Now()
	serverUpDuration := time.Duration(testconfig.TestConf.Server.ServerUpDurationInSec) * time.Second
	var clientTestDuration time.Duration
	if testconfig.TestConf.Client.LoadParameters != nil {
		clientTestDuration = time.Duration(testconfig.TestConf.Client.LoadParameters.TestDurationInSec) * time.Second
	} else {
		clientTestDuration = 0
	}
	for {
		select {
		case clientErr := <-clientErrorChannel:
			cleanUpTestCase()
			testCaseStatus[testIdentifier] = []string{"FAILED", clientErr}
			return
		case serverErr := <-serverErrorChannel:
			cleanUpTestCase()
			testCaseStatus[testIdentifier] = []string{"FAILED", serverErr}
			return
		default:
			if serverUpDuration != 0 && time.Since(startTime) >= serverUpDuration {
				cleanUpTestCase()
				testCaseStatus[testIdentifier] = []string{"PASSED"}
				return
			} else if clientTestDuration != 0 && time.Since(startTime) >= clientTestDuration {
				cleanUpTestCase()
				testCaseStatus[testIdentifier] = []string{"PASSED"}
				return
			}

		}
	}
}

//StopTestCase Stops the test case execution
func StopTestCase(sut, testsuite, testcase string) error {
	testIdentifier := fmt.Sprintf("%s-%s-%s", sut, testsuite, testcase)
	teststatus, ok := testCaseStatus[testIdentifier]
	if !ok || teststatus[0] != "IN_PROGRESS" {
		return errors.New("testIsNotRunning: The requested test is not running")
	}
	select {
	case <-testcaseStopIndicator:
	default:
		close(testcaseStopIndicator)
	}
	server.CloseAllServerInstances()
	testCaseStatus[testIdentifier] = []string{"STOPPED"}
	anyTestRunning = false
	return nil

}

//endTestCase Stops the test case execution
func cleanUpTestCase() error {
	select {
	case <-testcaseStopIndicator:
	default:
		close(testcaseStopIndicator)
	}
	server.CloseAllServerInstances()
	anyTestRunning = false
	return nil
}

//GetTestCaseStatus - Gets the test case status
func GetTestCaseStatus(sut, testsuite, testcase string) (string, string, error) {
	testIdentifier := fmt.Sprintf("%s-%s-%s", sut, testsuite, testcase)
	testStatus, ok := testCaseStatus[testIdentifier]
	if !ok {
		return "", "", errors.New("testDetailsNotAvailble: Test details are not availble. The test is not initialised")
	}
	if len(testStatus) == 2 {
		return testStatus[0], testStatus[1], nil
	}
	return testStatus[0], string(""), nil
}
