package nflogger

import (
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"nf-simulator/config"
	"path"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"

	"github.com/natefinch/lumberjack"
)

var logconfig = config.ProductConfig.Logger

type logLevel struct {
	err, warning, trace, info, debug, testResult *log.Logger
}

type writer struct {
	errorWriter, traceWriter, infoWriter, debugWriter, testResultWriter io.Writer
}

var loglevel logLevel

func getLogWriter(logPath string) writer {
	errorLogFile := path.Join(logPath, config.ErrorLogFile)
	traceLogFile := path.Join(logPath, config.TraceLogFile)
	infoLogFile := path.Join(logPath, config.InfoLogFile)
	debugLogFile := path.Join(logPath, config.DebugLogFile)
	testResultLogFile := path.Join(logPath, "../../", config.TestResultLogFile)

	errorWriter := &lumberjack.Logger{
		Filename:   errorLogFile,
		MaxSize:    logconfig.MaxLogFileSize,
		MaxBackups: logconfig.MaxLogFileBackups,
		MaxAge:     logconfig.MaxLogFileAge,
		Compress:   logconfig.Compress,
	}

	traceWriter := &lumberjack.Logger{
		Filename:   traceLogFile,
		MaxSize:    logconfig.MaxLogFileSize,
		MaxBackups: logconfig.MaxLogFileBackups,
		MaxAge:     logconfig.MaxLogFileAge,
		Compress:   logconfig.Compress,
	}

	infoWriter := &lumberjack.Logger{
		Filename:   infoLogFile,
		MaxSize:    logconfig.MaxLogFileSize,
		MaxBackups: logconfig.MaxLogFileBackups,
		MaxAge:     logconfig.MaxLogFileAge,
		Compress:   logconfig.Compress,
	}

	debugWriter := &lumberjack.Logger{
		Filename:   debugLogFile,
		MaxSize:    logconfig.MaxLogFileSize,
		MaxBackups: logconfig.MaxLogFileBackups,
		MaxAge:     logconfig.MaxLogFileAge,
		Compress:   logconfig.Compress,
	}

	testResultWriter := &lumberjack.Logger{
		Filename:   testResultLogFile,
		MaxSize:    logconfig.MaxLogFileSize,
		MaxBackups: logconfig.MaxLogFileBackups,
		MaxAge:     logconfig.MaxLogFileAge,
		Compress:   logconfig.Compress,
	}
	return writer{errorWriter: errorWriter, traceWriter: traceWriter,
		infoWriter: infoWriter, debugWriter: debugWriter, testResultWriter: testResultWriter}
}

//InitialiseLogger initialises all the log levels based on log configurations
func InitialiseLogger(logPath string) {
	logconfig = config.ProductConfig.Logger
	writer := getLogWriter(logPath)

	loglevel.testResult = log.New(writer.testResultWriter,
		"", log.Ldate|log.Ltime)

	if strings.ToLower(logconfig.LogLevel) == "info" ||
		strings.ToLower(logconfig.LogLevel) == "trace" {
		loglevel.err = log.New(writer.errorWriter,
			"", log.Ldate|log.Ltime)
		loglevel.warning = log.New(writer.errorWriter,
			"", log.Ldate|log.Ltime)
		loglevel.trace = log.New(writer.traceWriter,
			"", log.Ldate|log.Ltime)
		loglevel.info = log.New(writer.infoWriter,
			"", log.Ldate|log.Ltime)
		loglevel.debug = log.New(writer.debugWriter,
			"", log.Ldate|log.Ltime)
		loglevel.debug.SetOutput(ioutil.Discard)

		if strings.ToLower(logconfig.LogLevel) == "trace" {
			loglevel.trace.SetOutput(ioutil.Discard)
		}

	} else if strings.ToLower(logconfig.LogLevel) == "debug" {
		errWriter := io.MultiWriter(writer.errorWriter, writer.debugWriter)
		loglevel.err = log.New(errWriter,
			"", log.Ldate|log.Ltime)
		loglevel.warning = log.New(errWriter,
			"", log.Ldate|log.Ltime)
		traceWriter := io.MultiWriter(writer.traceWriter, writer.debugWriter)
		loglevel.trace = log.New(traceWriter,
			"", log.Ldate|log.Ltime)
		infoWriter := io.MultiWriter(writer.infoWriter, writer.debugWriter)
		loglevel.info = log.New(infoWriter,
			"", log.Ldate|log.Ltime)
		loglevel.debug = log.New(writer.debugWriter,
			"", log.Ldate|log.Ltime)
	}

	if logconfig.DisableLogging == true {
		loglevel.trace.SetOutput(ioutil.Discard)
		loglevel.info.SetOutput(ioutil.Discard)
		loglevel.debug.SetOutput(ioutil.Discard)
	}

}

//LogError logs given error log to the log file
func LogError(logMessage ...interface{}) {
	pc := make([]uintptr, 10)
	runtime.Callers(2, pc)
	f := runtime.FuncForPC(pc[0])
	file, line := f.FileLine(pc[0])
	file = filepath.Base(file)
	lineStr := strconv.Itoa(line)
	fnName := f.Name()
	caller := "[" + file + ": " + fnName + ":" + lineStr + "]"
	logMessageStr := strings.TrimLeft(strings.TrimRight(fmt.Sprintf("%s", logMessage), "]"), "[")
	loglevel.err.Println(caller, "[ERROR] -", logMessageStr)
}

//LogWarning logs given error log to the log file
func LogWarning(logMessage ...interface{}) {
	pc := make([]uintptr, 10)
	runtime.Callers(2, pc)
	f := runtime.FuncForPC(pc[0])
	file, line := f.FileLine(pc[0])
	file = filepath.Base(file)
	lineStr := strconv.Itoa(line)
	fnName := f.Name()
	caller := "[" + file + ": " + fnName + ":" + lineStr + "]"
	logMessageStr := strings.TrimLeft(strings.TrimRight(fmt.Sprintf("%s", logMessage), "]"), "[")
	loglevel.warning.Println(caller, "[WARNING] -", logMessageStr)
}

//LogEntry logs given Entry to the function
func LogEntry() {
	if logconfig.DisableLogging == true {
		return
	}
	pc := make([]uintptr, 10)
	runtime.Callers(2, pc)
	f := runtime.FuncForPC(pc[0])
	file, line := f.FileLine(pc[0])
	file = filepath.Base(file)
	lineStr := strconv.Itoa(line)
	fnName := f.Name()
	caller := "[" + file + ": " + fnName + ":" + lineStr + "]"
	//caller := helper.GetCallerDetails()
	loglevel.trace.Println(caller, "[TRACE] -", ">>>")
}

//LogExit logs the exit from the function
func LogExit() {
	if logconfig.DisableLogging == true {
		return
	}
	pc := make([]uintptr, 10)
	runtime.Callers(2, pc)
	f := runtime.FuncForPC(pc[0])
	file, line := f.FileLine(pc[0])
	file = filepath.Base(file)
	lineStr := strconv.Itoa(line)
	fnName := f.Name()
	caller := "[" + file + ": " + fnName + ":" + lineStr + "]"
	//caller := helper.GetCallerDetails()
	loglevel.trace.Println(caller, "[TRACE] -", "<<<")
}

//LogInfo logs given Info log to the log file
func LogInfo(logMessage ...interface{}) {
	if logconfig.DisableLogging == true {
		return
	}
	pc := make([]uintptr, 10)
	runtime.Callers(2, pc)
	f := runtime.FuncForPC(pc[0])
	file, line := f.FileLine(pc[0])
	file = filepath.Base(file)
	lineStr := strconv.Itoa(line)
	fnName := f.Name()
	caller := "[" + file + ": " + fnName + ":" + lineStr + "]"
	//caller := helper.GetCallerDetails()
	logMessageStr := strings.TrimLeft(strings.TrimRight(fmt.Sprintf("%v", logMessage), "]"), "[")
	loglevel.info.Println(caller, "[INFO] -", logMessageStr)
}

//LogDebug logs given Debug log to the log file
func LogDebug(logMessage ...interface{}) {
	if logconfig.DisableLogging == true {
		return
	}
	pc := make([]uintptr, 10)
	runtime.Callers(2, pc)
	f := runtime.FuncForPC(pc[0])
	file, line := f.FileLine(pc[0])
	file = filepath.Base(file)
	lineStr := strconv.Itoa(line)
	fnName := f.Name()
	caller := "[" + file + ": " + fnName + ":" + lineStr + "]"
	//caller := helper.GetCallerDetails()
	logMessageStr := strings.TrimLeft(strings.TrimRight(fmt.Sprintf("%v", logMessage), "]"), "[")
	loglevel.debug.Println(caller, "[DEBUG] -", logMessageStr)
}

//LogTestResult Logs test result of test cases
//If Arg is true logs as "PASSED", else logs as "FAILED"
func LogTestResult(isSuccess bool) {
	pc := make([]uintptr, 10)
	runtime.Callers(2, pc)
	f := runtime.FuncForPC(pc[0])
	file, _ := f.FileLine(pc[0])
	file = strings.Split(file, config.Project)[1]
	if isSuccess {
		loglevel.testResult.Printf(".%s: %s", file, "PASSED")
	} else {
		loglevel.testResult.Printf(".%s: %s", file, "FAILED")
	}
}
