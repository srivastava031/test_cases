package helper

import (
	"io/ioutil"
	"net"
	"net/http"
	"nf-simulator/config"
	customerror "nf-simulator/customerr"
	"os"
	"path"
	"path/filepath"
	"reflect"
	"runtime"
	"strconv"
	"strings"
)

//CompareMaps returns true when both the given maps are deeply equal.
//Map values are deeply equal when all of the following are true:
//they are both nil or both non-nil, they have the same length, and
//either they are the same map object or their corresponding keys
//(matched using Go equality) map to deeply equal values.
func CompareMaps(map1, map2 map[string]string) (bool, error) {
	isEqual := reflect.DeepEqual(map1, map2)
	return isEqual, nil
}

//IsValidIP Checks whether given strings is valid IPv4 or IPv6 or not.
//Returns true in case of valid, else returns false.
func IsValidIP(host string) bool {
	return net.ParseIP(host) != nil
}

//IsElementInSlice checks whether given element present in the slice.
//If present returns true, else returns false.
func IsElementInSlice(slice []interface{}, element interface{}) bool {
	for _, sliceElement := range slice {
		if sliceElement == element {
			return true
		}
	}
	return false
}

//GetCallerFileName returns the file name where
//this function is called.
func GetCallerFileName() string {
	pc := make([]uintptr, 10)
	runtime.Callers(2, pc)
	f := runtime.FuncForPC(pc[0])
	file, _ := f.FileLine(pc[0])
	return file
}

//GetWorkingDirectory returns the current working directory
func GetWorkingDirectory() (string, error) {
	wd, err := os.Getwd()
	if err != nil {
		return "", err
	}
	return wd, nil
}

//GetCallerDirectoryName returns the Directory
//name of the file where this function is called.
func GetCallerDirectoryName() (string, error) {
	pc := make([]uintptr, 10)
	runtime.Callers(2, pc)
	f := runtime.FuncForPC(pc[0])
	file, _ := f.FileLine(pc[0])
	callerDir := path.Dir(file)
	return callerDir, nil
}

//GetCallerDetails returns details of the function caller
func GetCallerDetails() string {
	pc := make([]uintptr, 10)
	runtime.Callers(2, pc)
	f := runtime.FuncForPC(pc[0])
	file, line := f.FileLine(pc[0])
	file = filepath.Base(file)
	lineStr := strconv.Itoa(line)
	fnName := f.Name()
	caller := "[" + file + ": " + fnName + ":" + lineStr + "]"
	return caller
}

//GetTestConfigFile returns the test configuration file for the give test case.
func GetTestConfigFile(testDir string) string {
	return path.Join(testDir, config.TestConfigFileName)
}

//GetHTTPHeaderFieldValue retriecves value for the given HTTP header field.
func GetHTTPHeaderFieldValue(header http.Header, fieldName string) (string, error) {
	if value, ok := header[fieldName]; ok {
		val := strings.Join(value, "")
		return val, nil
	}
	return "", customerror.HeaderFieldNotPresent(fieldName)
}

//AddHTTPHeaderFields Adds header fields to the existing header
func AddHTTPHeaderFields(header, fields map[string]string) {
	for fieldName, value := range fields {
		header[fieldName] = value
	}
}

//GetMinAndMaxElementInArray -Returns smallest and largest value of the given arrary
func GetMinAndMaxElementInArray(a []int64) (min int64, max int64) {
	min = a[0]
	max = a[0]
	for _, value := range a {
		if value < min {
			min = value
		}
		if value > max {
			max = value
		}
	}
	return min, max
}

//GetMinElementInArray -Returns smallest and largest value of the given arrary
func GetMinElementInArray(a []int64) (min int64) {
	min = a[0]
	for _, value := range a {
		if value < min {
			min = value
		}
	}
	return min
}

//GetMaxElementInArray -Returns smallest and largest value of the given arrary
func GetMaxElementInArray(a []int64) (max int64) {
	max = a[0]
	for _, value := range a {
		if value > max {
			max = value
		}
	}
	return max
}

//GetAverageOfArrayElements retuns average of the array elements
func GetAverageOfArrayElements(array []int64) int64 {
	sum := int64(0)
	for _, elem := range array {
		sum += elem
	}

	return sum / int64(len(array))

}

//ListDirectories Lists all the directories under the given path
func ListDirectories(path string) ([]string, error) {
	files, err := ioutil.ReadDir(path)
	if err != nil {
		return nil, err
	}

	var directories []string
	for _, f := range files {
		if f.IsDir() {
			directories = append(directories, f.Name())

		}
	}
	return directories, nil
}

//IsPathExist returns true if the given path exists else returns false.
func IsPathExist(path string) bool {
	if _, err := os.Stat(path); os.IsNotExist(err) {
		return false
	}
	return true
}
