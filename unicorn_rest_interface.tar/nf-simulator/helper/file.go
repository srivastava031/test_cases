package helper

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	customerror "nf-simulator/customerr"
	"text/template"

	"github.com/jeremywohl/flatten"
	"github.com/tidwall/gjson"
)

//ReadFile Reads the given file and returns the content.
//In case of failure returns the error
func ReadFile(fname string) (string, error) {
	data, err := ioutil.ReadFile(fname)
	if err != nil {
		return "", err
	}
	return string(data), nil
}

//GetFlattenedJSONFromFile returns the nested json keys and their values in the format of map
//The keys are seperated by dot(.)
func GetFlattenedJSONFromFile(fname string) (map[string]interface{}, error) {
	data, err := ReadFile(fname)
	if err != nil {
		return nil, err
	}
	flattenedJSON, err := GetFlattenedJSONFromString(data)
	if err != nil {
		return nil, err
	}
	return flattenedJSON, nil
}

//GetFlattenedJSONFromString returns the nested json keys and their values in the format of map
//The keys are seperated by dot(.)
func GetFlattenedJSONFromString(jsonString string) (map[string]interface{}, error) {
	flattenedJSONString, err := flatten.FlattenString(jsonString, "", flatten.DotStyle)
	flattenedJSON := make(map[string]interface{})
	err = json.Unmarshal([]byte(flattenedJSONString), &flattenedJSON)
	if err != nil {
		return nil, err
	}
	return flattenedJSON, nil
}

//IsValidJSONString validates the JSON string
//Returns true if valid, else returns false
func IsValidJSONString(jsonString string) bool {
	if !gjson.Valid(jsonString) {
		return false
	}
	return true
}

//IsValidJSONFile validates the JSON string
//Returns true if valid, else returns false
func IsValidJSONFile(jsonFile string) (bool, error) {
	jsonString, err := ReadFile(jsonFile)
	if err != nil {
		return false, err
	}
	isValid := IsValidJSONString(jsonString)
	return isValid, nil
}

//GetValueFromJSONString fetches the value for the given path
//Here Path is Dot(.) seperated string for the nested key.
func GetValueFromJSONString(jsonString, path string) (string, error) {
	if !IsValidJSONString(jsonString) {
		return "", customerror.ErrInvalidJSONString
	}
	value := gjson.Get(jsonString, path)
	if !value.Exists() {
		return "", customerror.ErrInvalidJSONPath
	}
	return value.String(), nil
}

//GetValueFromJSONFile fetches the value for the given path
//Here Path is Dot(.) seperated string for the nested key.
func GetValueFromJSONFile(jsonFile, path string) (string, error) {
	data, err := ReadFile(jsonFile)
	if err != nil {
		return "", err
	}
	value, err := GetValueFromJSONString(data, path)
	if err != nil {
		return "", err
	}
	return value, nil
}

//IsElemntExistsInJson - If path exists in the JSON string returns true,
//otherwise returns false. Returns error in case of invalid json string.
//Here path is Dot(.) seperated value.
func IsElemntExistsInJson(jsonString, path string) (bool, error) {
	isValid := IsValidJSONString(jsonString)
	if !isValid {
		return false, customerror.ErrInvalidJSONString
	}
	value := gjson.Get(jsonString, path)
	if !value.Exists() {
		return false, nil
	}
	return true, nil
}

//RenderTemplate renders the configs into template and returns the generated content
func RenderTemplate(templateFile string, config map[string]string) (string, error) {
	t, err := template.ParseFiles(templateFile)
	if err != nil {
		return "", err
	}

	var templt bytes.Buffer
	err = t.Execute(&templt, config)
	if err != nil {
		return "", err
	}
	content := templt.String()

	return content, nil

}

//RenderTemplateFromString renders the configs into template and returns the generated content
func RenderTemplateFromString(templateStr string, config map[string]string) (string, error) {
	t := template.Must(template.New("tmpl").Parse(templateStr))
	var templt bytes.Buffer
	err := t.Execute(&templt, config)
	if err != nil {
		return "", err
	}
	content := templt.String()

	return content, nil

}
