package counters

import (
	"encoding/binary"
	"net"
	"nf-simulator/testconfig"
	"reflect"
	"strconv"
	"strings"
	"sync/atomic"
)

var Counters = map[string]*CounterConfig{}

type CounterConfig struct {
	Name, Format                                                         string
	trackIndependtlyForEachConnection, resetAfterEachIterationOfCallFlow bool
	increment                                                            int
	start, end, current                                                  uint64
}

func New(name string, start string, end string, format string, increment int, trackIndependtlyForEachConnection, resetAfterEachIterationOfCallFlow bool) (*CounterConfig, error) {
	c := new(CounterConfig)
	c.Name = name
	c.Format = format
	if strings.ToLower(format) == "ipv4" {
		c.start = ipv4String2Int(start) - uint64(increment)
		c.end = ipv4String2Int(end) - uint64(increment)
		c.current = c.start
	} else if strings.ToLower(format) == "int" {
		startInInt, err := strconv.ParseUint(start, 10, 64)
		if err != nil {
			return c, err
		}
		c.start = startInInt - uint64(increment)
		endInInt, err := strconv.ParseUint(end, 10, 64)
		if err != nil {
			return c, err
		}
		c.current = c.start
		c.end = endInInt - uint64(increment)
	} else {
	}
	c.trackIndependtlyForEachConnection = trackIndependtlyForEachConnection
	c.resetAfterEachIterationOfCallFlow = resetAfterEachIterationOfCallFlow
	c.increment = increment
	return c, nil
}

func ipv4String2Int(ipv4Address string) uint64 {
	return uint64(binary.BigEndian.Uint32(net.ParseIP(ipv4Address)[12:16]))
}

func ipv4Int2String(ipv4InInt uint64) string {
	firstOctet := strconv.FormatUint((ipv4InInt>>24)&0xff, 10)
	secondOctet := strconv.FormatUint((ipv4InInt>>16)&0xff, 10)
	thirdOctet := strconv.FormatUint((ipv4InInt>>8)&0xff, 10)
	fourthOctet := strconv.FormatUint((ipv4InInt & 0xff), 10)
	return firstOctet + "." + secondOctet + "." + thirdOctet + "." + fourthOctet
}

func (c *CounterConfig) GetNextCount() string {
	if c.Format == "ipv4" {
		if c.current >= 4294967296 || c.current > c.end {
			c.current = c.start
		}
		c.current = atomic.AddUint64(&c.current, uint64(c.increment))
		return ipv4Int2String(c.current)
	} else {
		if c.current > c.end {
			c.current = c.start
		}
		c.current = atomic.AddUint64(&c.current, uint64(c.increment))
		return strconv.FormatUint(c.current, 10)
	}
}

func InitialiseCounters() error {
	for _, counter := range testconfig.TestConf.Counters {
		counterInstance, err := New(counter.Name, counter.StartAt, counter.EndAt, counter.Type,
			counter.IncrementBy, counter.TrackIndependtlyForEachConnection,
			counter.ResetAfterEachIterationOfCallFlow)
		if err != nil {
			return err
		}
		Counters[counter.Name] = counterInstance
	}
	return nil
}

func GetAllCounters() []string {
	keys := reflect.ValueOf(Counters).MapKeys()
	var counterz []string
	for _, val := range keys {
		counterz = append(counterz, val.Interface().(string))
	}
	return counterz
}

func GetCounterInstance(counterName string) *CounterConfig {
	return Counters[counterName]
}
