package counters

import (
	"errors"
	"nf-simulator/helper"
	"nf-simulator/nflogger"
	"strings"
)

func GetUpdatedEndpointWithCounter(endpoint string) (string, error) {
	if !strings.Contains(endpoint, "{{.") {
		return endpoint, nil
	}
	counters := GetAllCounters()
	if counters == nil {
		err := errors.New("Counters not defined")
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return "", err
	}
	config := map[string]string{}
	for _, val := range counters {
		if strings.Contains(endpoint, val+"}}") {
			config[val] = GetCounterInstance(val).GetNextCount()
		}
	}
	updatedEndpoint, err := helper.RenderTemplateFromString(endpoint, config)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return "", err
	}
	return updatedEndpoint, nil
}

func GetUpdatedStringWithCounter(stringForUpdate string) (string, error) {
	if !strings.Contains(stringForUpdate, "{{.") {
		return stringForUpdate, nil
	}
	counters := GetAllCounters()
	if counters == nil {
		err := errors.New("Counters not defined")
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return "", err
	}
	config := map[string]string{}
	for _, val := range counters {
		if strings.Contains(stringForUpdate, val+"}}") {
			config[val] = GetCounterInstance(val).GetNextCount()
		}
	}
	updatedString, err := helper.RenderTemplateFromString(stringForUpdate, config)
	if err != nil {
		nflogger.LogError(err.Error())
		nflogger.LogExit()
		return "", err
	}
	return updatedString, nil
}

func GetUpdatedHTTPBodyWithCounters(httpBodyTemplate string) (string, error) {
	config := map[string]string{}
	counters := GetAllCounters()
	if counters != nil && strings.Contains(httpBodyTemplate, "{{.") {
		for _, val := range counters {
			if strings.Contains(httpBodyTemplate, val+"}}") {
				config[val] = GetCounterInstance(val).GetNextCount()

			}
		}
		updatedHTTPBody, err := helper.RenderTemplateFromString(httpBodyTemplate, config)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return "", err
		}
		return updatedHTTPBody, nil
	}
	return httpBodyTemplate, nil
}

func GetUpdatedQueryParametersWithCounters(queryParameters map[string]string) (map[string]string, error) {
	var config map[string]string
	var err error
	updatedQueryParams := map[string]string{}
	counters := GetAllCounters()
	for queryParam, queryValue := range queryParameters {
		config = map[string]string{}
		if strings.Contains(queryValue, "}}") {
			for _, val := range counters {
				if strings.Contains(queryValue, val+"}}") {
					config[val] = GetCounterInstance(val).GetNextCount()
				}
			}
			updatedQueryParams[queryParam], err = helper.RenderTemplateFromString(queryValue, config)
			if err != nil {
				return nil, err
			}
		} else {
			updatedQueryParams[queryParam] = queryValue
		}
	}
	return updatedQueryParams, nil
}

func GetUpdateHeaderWithCounters(header map[string]string) (map[string]string, error) {
	var config map[string]string
	var err error
	updatedHeader := map[string]string{}
	counters := GetAllCounters()
	for field, value := range header {
		config = map[string]string{}
		if strings.Contains(value, "}}") {
			for _, val := range counters {
				if strings.Contains(value, val+"}}") {
					config[val] = GetCounterInstance(val).GetNextCount()
				}
			}
			updatedHeader[field], err = helper.RenderTemplateFromString(value, config)
			if err != nil {
				return nil, err
			}
		} else {
			updatedHeader[field] = value
		}

	}
	return updatedHeader, nil
}
