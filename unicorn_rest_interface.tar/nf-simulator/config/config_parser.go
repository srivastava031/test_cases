package config

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
)

var ProductConfig ProductConf

type Logger struct {
	MaxLogFileSize, MaxLogFileBackups, MaxLogFileAge int
	LogLevel                                         string
	DisableLogging, Compress                         bool
}

type Encoding struct {
	DisableFormEncoding bool
}

type Stats struct {
	StatsIntervalInSec int
}

type ProductConf struct {
	Logger   Logger
	Stats    Stats
	Encoding Encoding
}

func InitialiseProductConfig() {
	config, err := ioutil.ReadFile(productConfigFile)
	if err != nil {
		fmt.Print(err)
	}

	json.Unmarshal(config, &ProductConfig)
}
