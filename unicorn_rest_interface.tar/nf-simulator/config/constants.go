package config

//TIMEOUT - Global Timeout.
//This is maximum wait time for the events to finish their action.
const (
	Project            = "unicorn"
	productConfigFile  = "/opt/unicorn/config/nf.json"
	ErrorLogFile       = "nf_error.log"
	TraceLogFile       = "nf_trace.log"
	InfoLogFile        = "nf_info.log"
	DebugLogFile       = "nf_debug.log"
	TestConfigFileName = "test_config.json"
	TestResultLogFile  = "test_result.log"
	StatsFile          = "statistics.out"
	TestPath           = "/opt/unicorn/testcases/"
)
