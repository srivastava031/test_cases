package test

import "net/http"

//CallbackMap will have all the registered callbacks from the test case.
//Here the Key is CallBack Identifier and value is Callback function
var CallbackMap = make(map[string]func(messageID string, args ...interface{}) (http.Header, string, map[string]string, error))

//RegisterCallback API can be used by the test case writer to
//register the Request or Response callback functions.
func RegisterCallback(callbackID string, callbackFunction func(messageID string, args ...interface{}) (http.Header, string, map[string]string, error)) {
	CallbackMap[callbackID] = callbackFunction
}
