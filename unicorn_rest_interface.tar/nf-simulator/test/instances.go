package test

import (
	"io"
	"net/http"
	"nf-simulator/http02"
	"nf-simulator/nflogger"
	"nf-simulator/testconfig"
	"os"
)

//Connection struact contains http client instance and Endpoint
type Connection struct {
	Instance *http.Client
	EndPoint string
}

//Connections is an array of connections
var Connections []Connection

//CreateInstances creates the instances configutred in the test configuration
func CreateInstances(testConfigFile string) error {
	nflogger.LogEntry()
	nflogger.LogInfo("Getting instances from test configuration.")
	Connections = nil
	loadConfig := testconfig.TestConf.Client.LoadParameters
	//TODO - Current approach works only for single client and single server
	//TODO Server part have to be include after server APIs implementation
	var keyLogWriter io.Writer
	var err error
	if testconfig.TestConf.Client.TLSConfig.GeneratePreMasterSecretLog == true {
		keyLogWriter, err = os.OpenFile("client-ssl-key.log", os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0655)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return err
		}
	}
	var connectionsPerEndPoint int
	if loadConfig != nil {
		if loadConfig.Endpoints != nil {
			connectionsPerEndPoint = loadConfig.NumberOfConnections / len(loadConfig.Endpoints)
		} else {
			connectionsPerEndPoint = loadConfig.NumberOfConnections
		}
	}

	var numberOfConnections int
	var connection *Connection

	if loadConfig.NumberOfConnections == 0 {
		nflogger.LogInfo("Creating single connection object")
		client, err := http02.CreateH2Client(keyLogWriter)
		if err != nil {
			nflogger.LogError(err.Error())
			nflogger.LogExit()
			return err
		}
		connection = new(Connection)
		connection.Instance = client
		connection.EndPoint = ""
		Connections = append(Connections, *connection)
	} else {
		numberOfConnections = loadConfig.NumberOfConnections
		nflogger.LogInfo("Creating", numberOfConnections, "connection objects")

		for connectionIndex, endPointIndex := 1, 0; connectionIndex <= numberOfConnections; connectionIndex++ {
			client, err := http02.CreateH2Client(keyLogWriter)
			if err != nil {
				nflogger.LogError(err.Error())
				nflogger.LogExit()
				return err
			}

			connection = new(Connection)
			connection.Instance = client
			connection.EndPoint = loadConfig.Endpoints[endPointIndex]
			Connections = append(Connections, *connection)
			if connectionIndex%connectionsPerEndPoint == 0 {
				endPointIndex++
			}
		}
	}
	nflogger.LogExit()
	return nil
}
