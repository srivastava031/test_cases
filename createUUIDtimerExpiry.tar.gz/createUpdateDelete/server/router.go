package server

import (
	"net/http"
	"strings"

	"github.com/gorilla/mux"
)

//Route is routing parameters
type Route struct {
	Name        string
	Method      string
	Pattern     string
	HandlerFunc http.HandlerFunc
}

//Routes stores routes as slice
type Routes []Route

var routes = Routes{
	Route{
		"HandleTimeout",
		strings.ToUpper("Post"),
		"/nchf-convergedcharging/v2/chargingdata/",
		handleCreateRequest,
	},
	{
		"HandleTimeout",
		strings.ToUpper("Post"),
		"/nchf-convergedcharging/v2/chargingdata/{ID}",
		handleUpdateRequest,
	},
}

func NewRouter() *mux.Router {
	router := mux.NewRouter()
	for _, route := range routes {
		var handler http.Handler
		handler = route.HandlerFunc

		router.Methods(route.Method).Path(route.Pattern).Name(route.Name).Handler(handler) //this is calling function
	}

	return router
}
