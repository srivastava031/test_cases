package server

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"time"

	chanel "uuid-setReset/expiryResetTimer"

	"github.com/gorilla/mux"
	uui "github.com/satori/go.uuid"
)

//decodes the resuest body sent
func decodeReqBody(r *http.Request) error {
	content := make(map[string]interface{})
	reqBody, _ := ioutil.ReadAll(r.Body)
	defer r.Body.Close()
	re := bytes.NewReader(reqBody)
	err := json.NewDecoder(re).Decode(&content)
	if err != nil {
		return err
	}
	return nil
}

//sends param to all running goroutine channels
func broadcast(params string) {
	for i := 1; i <= len(chanel.Maap); i++ {
		chanel.Ch <- params
	}
	fmt.Println("\nBROADCAST DONE\n")
	return
}

//handleMessage handles if url comes with url id
func handleUpdateRequest(w http.ResponseWriter, r *http.Request) {

	params := mux.Vars(r)["ID"]
	go broadcast(params)

	if len(chanel.Maap) == 0 {
		w.WriteHeader(http.StatusNoContent)
	}
	ii := 0
	for index := range chanel.Maap {

		if params == index {
			newPath := "/nchf-convergedcharging/v2/chargingdata/" + params
			w.Header().Set("request-uri", newPath)
			b := decodeReqBody(r)
			if b != nil {
				w.WriteHeader(http.StatusBadRequest)
			}
			w.Header().Set("Content-Type", "application/json; charset=UTF-8")
			break
		} else if ii == (len(chanel.Maap) - 1) {
			w.WriteHeader(http.StatusNoContent)
		}
		ii++
	}
}

//handleMessage handles if url comes without url id
func handleCreateRequest(w http.ResponseWriter, r *http.Request) {
	uid := (uui.NewV4()).String()
	time := (time.Now().Format(time.RFC850))
	chanel.Maap[uid] = time
	go chanel.Del(uid)
	fmt.Println("===>", chanel.Maap)
	fmt.Println("temp=", uid)
	newPath := "/nchf-convergedcharging/v2/chargingdata/" + uid
	fmt.Printf("\n%v\n", newPath)
	w.Header().Set("request-uri", newPath)
	b := decodeReqBody(r)
	if b != nil {
		w.WriteHeader(http.StatusBadRequest)
	}
	w.Header().Set("Content-Type", "application/json; charset=UTF-8")
	return

}
