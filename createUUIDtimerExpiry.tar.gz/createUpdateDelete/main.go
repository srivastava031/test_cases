package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"runtime"
	"time"
	serv "uuid-setReset/server"

	"golang.org/x/net/http2"
	"golang.org/x/net/http2/h2c"
)

func main() {
	fmt.Println("NUMBER OF ROUTINE RUNING", runtime.NumGoroutine())
	router := serv.NewRouter()
	listnerPort := fmt.Sprintf(":%d", 8080)

	h2server := &http2.Server{}
	server := &http.Server{
		Addr:        listnerPort,
		Handler:     h2c.NewHandler(router, h2server), //here router is nothing but serveMux which itself is Handler, as it is having method serveHttp attached to it
		IdleTimeout: 100 * time.Second,
	}
	log.Println("Started listening on port 8080")
	fmt.Println("============")
	if err := server.ListenAndServe(); err != nil {
		log.Println("failed to listen server : ", err)
		os.Exit(1)

	}
	fmt.Println("======||======")

	fmt.Println("end statement")

}
