package expiryresettimer

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"time"
)

//Maap will store the generated uid
var Maap = make(map[string]string)

//Ch channel used to broadcast the reciever uid from url
var Ch = make(chan string, len(Maap))

//Del function deletes the uid when time limit exceeds or reset if uid sent within time range
func Del(uid string) {

	timeval := getFromJSON("time")
	tmr := time.NewTimer(timeval)
	for {
		select {
		case <-tmr.C:
			fmt.Println("DELETING THE IID==>>", uid)
			delete(Maap, uid)
			fmt.Println("IID DELETED==>>", uid)
			tmr.Stop()
			return

		case val := <-Ch:
			if val == uid {
				tmr.Stop()
				tmr.Reset(30 * time.Second)
				fmt.Printf("\ntimer reset done\n")
			}
			continue

		}
	}
}

//gets the time value from the json file
func getFromJSON(t string) time.Duration {
	m := make(map[string]int)
	f, err := os.Open("/home/asus/Desktop/createUpdateDelete/config.json")
	if err != nil {
		fmt.Println(err)
	}
	jsonByte, err := ioutil.ReadAll(f)
	if err != nil {
		log.Println(err)
	}
	json.Unmarshal(jsonByte, &m)
	tm := m[t]
	d2 := (time.Duration(tm) * time.Second)
	return d2

}
